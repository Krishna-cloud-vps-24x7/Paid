import discord
from discord.ext import commands, tasks
import os
from dotenv import load_dotenv
from datetime import datetime, timedelta
from utils.database import db
from utils import lxc
import logging

load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


intents = discord.Intents.default()
intents.message_content = True
intents.members = True # Needed to fetch user objects

bot = commands.Bot(command_prefix='!', intents=intents)

@tasks.loop(hours=24)
async def check_vps_payments():
    await bot.wait_until_ready()
    logging.info("Running daily VPS payment check...")
    all_vps = db.get_all_vps()
    now = datetime.now()

    for vps in all_vps:
        due_date = datetime.fromisoformat(vps['due_date'])
        user_id = vps['user_id']
        vps_id = vps['id']
        cost = vps['cost_credits']
        container_name = vps['container_name']
        status = vps['status']

        if now > due_date:
            user_balance = db.get_balance(user_id)
            user = None
            try:
                user = await bot.fetch_user(user_id)
            except discord.NotFound:
                logging.warning(f"User {user_id} not found, cannot send DM.")

            if status == 'active':
                if user_balance >= cost:
                    db.add_credits(user_id, -cost)
                    db.update_vps_due_date(vps_id)
                    logging.info(f"VPS {container_name} for user {user_id} has been renewed.")
                    if user:
                        try:
                            embed = discord.Embed(title="Renouvellement Automatique du VPS", description=f"Votre VPS `{container_name}` a été automatiquement renouvelé pour un mois supplémentaire. {cost} crédits ont été déduits de votre solde.", color=discord.Color.green())
                            await user.send(embed=embed)
                        except discord.Forbidden:
                            logging.warning(f"Cannot send renewal DM to user {user_id}. DMs are disabled.")
                else:
                    lxc.stop_container(container_name)
                    db.update_vps_status(vps_id, 'overdue')
                    logging.info(f"VPS {container_name} for user {user_id} is overdue and has been stopped.")
                    if user:
                        delete_timestamp = int((now + timedelta(days=2)).timestamp())
                        embed = discord.Embed(
                            title="VPS Payment Overdue",
                            description=f"Your VPS `{container_name}` has been stopped due to non-payment. You do not have enough credits ({user_balance}) to renew it for {cost} credits.",
                            color=discord.Color.orange()
                        )
                        embed.add_field(
                            name="Action Required",
                            value="Please top up your credits to reactivate your VPS. It will be automatically renewed once you have sufficient funds."
                        )
                        embed.add_field(
                            name="Deletion Date",
                            value=f"Your VPS will be permanently deleted <t:{delete_timestamp}:R> if not renewed.",
                            inline=False
                        )
                        try:
                            await user.send(embed=embed)
                        except discord.Forbidden:
                            logging.warning(f"Cannot send overdue DM to user {user_id}. DMs are disabled.")
            elif status == 'overdue':
                if user_balance >= cost:
                    db.add_credits(user_id, -cost)
                    db.update_vps_due_date(vps_id)
                    lxc.start_container(container_name)
                    logging.info(f"Overdue VPS {container_name} for user {user_id} has been renewed and started.")
                    if user:
                        try:
                            await user.send(f"✅ Your overdue VPS `{container_name}` has been renewed and is starting up.")
                        except discord.Forbidden:
                            logging.warning(f"Cannot send renewal DM to user {user_id}. DMs are disabled.")
                elif now > (due_date + timedelta(days=2)):
                    logging.info(f"VPS {container_name} for user {user_id} is being deleted due to non-payment.")
                    if lxc.delete_container(container_name):
                        db.delete_vps(vps_id)
                        logging.info(f"VPS {container_name} for user {user_id} has been deleted.")
                        if user:
                            try:
                                embed = discord.Embed(
                                    title="VPS Supprimé",
                                    description=f"Votre VPS `{container_name}` a été définitivement supprimé en raison du non-paiement.",
                                    color=discord.Color.red()
                                )
                                await user.send(embed=embed)
                            except discord.Forbidden:
                                logging.warning(f"Cannot send deletion DM to user {user_id}. DMs are disabled.")
                    else:
                        logging.error(f"Failed to delete container {container_name} for user {user_id}.")

@bot.check
async def is_in_correct_guild(ctx):
    if ctx.guild is None:
        return False
    return ctx.guild.id == 1337813607530102814

@bot.event
async def on_ready():
    print(f'We have logged in as {bot.user}')
    for filename in os.listdir('./commands'):
        if filename.endswith('.py'):
            try:
                await bot.load_extension(f'commands.{filename[:-3]}')
                print(f'Loaded command: {filename[:-3]}')
            except Exception as e:
                print(f'Failed to load command: {filename[:-3]}')
                print(f'[ERROR] {e}')
    try:
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} command(s)")
    except Exception as e:
        print(e)

    check_vps_payments.start()

bot.run(os.getenv("DISCORD_TOKEN"))
