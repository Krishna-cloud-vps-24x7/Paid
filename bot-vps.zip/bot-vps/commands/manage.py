import discord
from discord.ext import commands
from discord import app_commands # Import app_commands
from utils import lxc
from utils.database import db
import asyncio # Import asyncio
from utils.renew_vps import RenewModal
from commands.plans import PRICES, usd_to_credits
import math

class Manage(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="manage", description="View and manage your VPS instances.")
    @app_commands.guild_only()
    async def manage_vps(self, interaction: discord.Interaction):
        user_id = str(interaction.user.id)

        loop = asyncio.get_running_loop()
        user_containers = await loop.run_in_executor(None, lxc.list_user_containers, user_id)

        if not user_containers:
            embed = discord.Embed(
                title="Your VPS Instances",
                description="You don't have any VPS instances yet.",
                color=discord.Color.orange()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if len(user_containers) == 1:
            container_name = user_containers[0]
            await self.display_vps_info(interaction, container_name)
        else:
            # Create a select menu for multiple VPS
            select_options = [
                discord.SelectOption(label=name, value=name) for name in user_containers
            ]
            select = discord.ui.Select(
                placeholder="Choose a VPS to manage...",
                options=select_options,
                custom_id="vps_select"
            )

            async def select_callback(select_interaction: discord.Interaction):
                selected_container = select_interaction.data["values"][0]
                await self.display_vps_info(select_interaction, selected_container)

            select.callback = select_callback
            view = discord.ui.View(timeout=180)
            view.add_item(select)

            embed = discord.Embed(
                title="Your VPS Instances",
                description="You have multiple VPS instances. Please select one from the dropdown below:",
                color=discord.Color.orange()
            )
            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    async def display_vps_info(self, interaction: discord.Interaction, container_name: str):
        loop = asyncio.get_running_loop()
        vps_info_raw = await loop.run_in_executor(None, lxc.get_container_info, container_name)
        vps_db_info = db.get_vps_by_container_name(container_name)
        
        cpu_usage = "N/A"
        ram_usage = "N/A"
        disk_usage = "N/A"
        ssh_link = "N/A"
        uptime = "N/A"

        if vps_info_raw:
            import re
            from datetime import datetime

            def convert_to_mib(value_str, unit_str):
                value = float(value_str)
                if unit_str == "KiB":
                    return value / 1024
                elif unit_str == "MiB":
                    return value
                elif unit_str == "GiB":
                    return value * 1024
                elif unit_str == "TiB":
                    return value * 1024 * 1024
                return value # Fallback

            def format_size(mib_value):
                if mib_value >= 1024:
                    return f"{mib_value / 1024:.2f}GB"
                return f"{mib_value:.2f}MB"

            # Extract Status
            status_match = re.search(r"Status:\s*(\w+)", vps_info_raw)
            status = status_match.group(1) if status_match else "UNKNOWN"

            # Extract Created timestamp
            created_match = re.search(r"Created:\s*(\d{4}/\d{2}/\d{2} \d{2}:\d{2})", vps_info_raw)
            if created_match and status == "RUNNING":
                created_str = created_match.group(1)
                # Assuming CEST is +2 hours from UTC, but for simplicity, we'll parse without timezone for now
                # and calculate difference. For accurate timezone handling, more robust parsing is needed.
                created_dt = datetime.strptime(created_str, "%Y/%m/%d %H:%M")
                now_dt = datetime.now()
                delta = now_dt - created_dt
                days = delta.days
                hours, remainder = divmod(delta.seconds, 3600)
                minutes, seconds = divmod(remainder, 60)
                uptime = f"{days}j {hours}h {minutes}m"

            # Extract Memory Usage and Limit
            mem_usage_match = re.search(r"Memory usage:\s*\n\s*Memory \(current\):\s*([0-9.]+)([A-Za-z]+)", vps_info_raw)
            if mem_usage_match:
                mem_mib = convert_to_mib(mem_usage_match.group(1), mem_usage_match.group(2))
                formatted_mem_usage = format_size(mem_mib)
                if vps_db_info:
                    ram_usage = f"{formatted_mem_usage} / {vps_db_info['ram']}GB"
                else:
                    ram_usage = formatted_mem_usage

            # Extract Disk Usage and Limit
            disk_usage_match = re.search(r"Disk usage:\s*\n\s*root:\s*([0-9.]+)([A-Za-z]+)", vps_info_raw)
            if disk_usage_match:
                disk_mib = convert_to_mib(disk_usage_match.group(1), disk_usage_match.group(2))
                formatted_disk_usage = format_size(disk_mib)
                if vps_db_info:
                    disk_usage = f"{formatted_disk_usage} / {vps_db_info['disk']}GB"
                else:
                    disk_usage = formatted_disk_usage

        if vps_db_info and vps_db_info['ssh_link']:
            ssh_link = vps_db_info['ssh_link']

        embed = discord.Embed(
            title=f"VPS: {container_name}",
            color=discord.Color.orange()
        )
        embed.add_field(name="RAM Usage", value=ram_usage, inline=True)
        embed.add_field(name="Disk Usage", value=disk_usage, inline=True)
        embed.add_field(name="Uptime", value=uptime, inline=True)
        embed.add_field(name="SSH Link", value=f"```\n{ssh_link}\n```", inline=False)

        if vps_db_info:
            due_date = vps_db_info['due_date']
            cpu = vps_db_info['cpu']
            ram = vps_db_info['ram']
            disk = vps_db_info['disk']
            cost_usd = (cpu * PRICES["cpu"]) + (ram * PRICES["ram"]) + (disk * PRICES["disk"])
            cost_credits = usd_to_credits(cost_usd)
            embed.set_footer(text=f"Due Date: {due_date} | Cost: {cost_credits} credits/month")

        # Action Buttons
        stop_button = discord.ui.Button(label="Stop", style=discord.ButtonStyle.danger, custom_id=f"vps_stop_{container_name}")
        start_button = discord.ui.Button(label="Start", style=discord.ButtonStyle.success, custom_id=f"vps_start_{container_name}")
        reinstall_button = discord.ui.Button(label="Reinstall", style=discord.ButtonStyle.secondary, custom_id=f"vps_reinstall_{container_name}")
        other_button = discord.ui.Button(label="Other", style=discord.ButtonStyle.primary, custom_id=f"vps_other_{container_name}")

        view = discord.ui.View(timeout=180)
        view.add_item(stop_button)
        view.add_item(start_button)
        view.add_item(reinstall_button)
        view.add_item(other_button)

        stop_button.callback = self._stop_callback_method
        start_button.callback = lambda interaction: self._start_callback_method(interaction, embed, view)
        reinstall_button.callback = lambda interaction: self._reinstall_callback_method(interaction, embed, view)
        other_button.callback = lambda interaction: self._other_callback_method(interaction, embed, view)

        if interaction.response.is_done():
            await interaction.edit_original_response(embed=embed, view=view)
        else:
            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    async def _stop_callback_method(self, button_interaction: discord.Interaction):
        container_name = button_interaction.data['custom_id'].split("_")[-1]
        await button_interaction.response.send_message(f"Stopping {container_name}...", ephemeral=True)
        loop = asyncio.get_running_loop()
        if await loop.run_in_executor(None, lxc.stop_container, container_name):
            db.update_vps_ssh_link(container_name, None) # Clear SSH link from DB
            await button_interaction.edit_original_response(content=f"{container_name} stopped successfully.", view=None)
        else:
            await button_interaction.edit_original_response(content=f"Failed to stop {container_name}.", view=None)

    async def _start_callback_method(self, button_interaction: discord.Interaction, embed: discord.Embed, view: discord.ui.View):
        container_name = button_interaction.data['custom_id'].split("_")[-1]
        await button_interaction.response.send_message(f"Starting {container_name}...", ephemeral=True)
        loop = asyncio.get_running_loop()
        start_status = await loop.run_in_executor(None, lxc.start_container, container_name)

        if start_status is True: # Container was stopped and is now started
            new_ssh_link = await loop.run_in_executor(None, lxc.regenerate_ssh_link, container_name)
            if new_ssh_link:
                db.update_vps_ssh_link(container_name, new_ssh_link)
                embed.set_field_at(index=3, name="SSH Link", value=f"```\n{new_ssh_link}\n```", inline=False)
                await button_interaction.edit_original_response(content=f"{container_name} started and SSH link regenerated.", embed=embed, view=view)
            else:
                await button_interaction.edit_original_response(content=f"{container_name} started, but failed to regenerate SSH link.", embed=embed, view=view)
        elif start_status is None: # Container was already running
            await button_interaction.edit_original_response(content=f"{container_name} is already running.", embed=embed, view=view)
        else: # start_status is False, failed to start
            await button_interaction.edit_original_response(content=f"Failed to start {container_name}.", view=None)

    async def _reinstall_callback_method(self, button_interaction: discord.Interaction, embed: discord.Embed, view: discord.ui.View):
        container_name = button_interaction.data['custom_id'].split("_")[-1]
        await button_interaction.response.send_message(f"Reinstalling {container_name}. This will delete and recreate the VPS. Are you sure?", ephemeral=True, view=ConfirmReinstallView(container_name, self, embed, view))

    async def _other_callback_method(self, button_interaction: discord.Interaction, embed: discord.Embed, view: discord.ui.View):
        container_name = button_interaction.data['custom_id'].split("_")[-1]
        
        other_view = discord.ui.View(timeout=180)
        regen_ssh_button = discord.ui.Button(label="Regen-SSH", style=discord.ButtonStyle.primary, custom_id=f"vps_regen_ssh_{container_name}")
        delete_button = discord.ui.Button(label="Delete", style=discord.ButtonStyle.danger, custom_id=f"vps_delete_{container_name}")
        port_forward_button = discord.ui.Button(label="Port Forward", style=discord.ButtonStyle.secondary, custom_id=f"vps_port_forward_{container_name}")
        renew_button = discord.ui.Button(label="Renew", style=discord.ButtonStyle.success, custom_id=f"vps_renew_{container_name}")
        back_button = discord.ui.Button(label="Back", style=discord.ButtonStyle.secondary, custom_id=f"vps_back_{container_name}")

        other_view.add_item(regen_ssh_button)
        other_view.add_item(delete_button)
        other_view.add_item(port_forward_button)
        other_view.add_item(renew_button)
        other_view.add_item(back_button)

        async def _regen_ssh_callback_inner(regen_interaction: discord.Interaction):
            container_name = regen_interaction.data['custom_id'].split("_")[-1]
            await regen_interaction.response.defer()
            loop = asyncio.get_running_loop()
            new_ssh_link = await loop.run_in_executor(None, lxc.regenerate_ssh_link, container_name)
            if new_ssh_link:
                db.update_vps_ssh_link(container_name, new_ssh_link)
                embed.set_field_at(index=3, name="SSH Link", value=f"```\n{new_ssh_link}\n```", inline=False)
                await regen_interaction.edit_original_response(content=f"SSH link for {container_name} regenerated successfully.", embed=embed, view=view)
            else:
                await regen_interaction.edit_original_response(content=f"Failed to regenerate SSH link for {container_name}.", view=other_view)

        async def _back_callback_inner(back_interaction: discord.Interaction):
            await back_interaction.response.edit_message(embed=embed, view=view)

        async def _renew_callback_inner(renew_interaction: discord.Interaction):
            container_name = renew_interaction.data['custom_id'].split("_")[-1]
            await renew_interaction.response.send_modal(RenewModal(container_name))

        regen_ssh_button.callback = _regen_ssh_callback_inner
        delete_button.callback = lambda interaction: self._delete_callback_method(interaction, embed, view)
        port_forward_button.callback = lambda interaction: self._port_forward_callback_method(interaction, embed, view)
        renew_button.callback = _renew_callback_inner
        back_button.callback = _back_callback_inner

        await button_interaction.response.edit_message(view=other_view)

    async def _delete_callback_method(self, button_interaction: discord.Interaction, embed: discord.Embed, view: discord.ui.View):
        container_name = button_interaction.data['custom_id'].split("_")[-1]
        await button_interaction.response.send_message(f"Deleting {container_name}. This will permanently delete the VPS. Are you sure?", ephemeral=True, view=ConfirmDeleteView(container_name, self, embed, view))

    async def _port_forward_callback_method(self, button_interaction: discord.Interaction, embed: discord.Embed, view: discord.ui.View):
        container_name = button_interaction.data['custom_id'].split("_")[-1]

        # Get existing forwarded ports
        loop = asyncio.get_running_loop()
        existing_forwards = await loop.run_in_executor(None, lxc.list_port_forwards, container_name)

        # Create the modal, passing existing_forwards
        modal = PortForwardModal(container_name, self.bot, existing_forwards)
        # Send the modal as the initial response
        await button_interaction.response.send_modal(modal)

        # After sending the modal, send the embed with existing forwards as a followup
        if existing_forwards:
            forward_list = "\n".join([f"- {f}" for f in existing_forwards])
            embed = discord.Embed(
                title=f"Ports already forwarded for {container_name}",
                description=f"```\n{forward_list}\n```",
                color=discord.Color.orange()
            )
        else:
            embed = discord.Embed(
                title=f"Ports already forwarded for {container_name}",
                description="No ports forwarded for now.",
                color=discord.Color.orange()
            )
        
        await button_interaction.followup.send(embed=embed, ephemeral=True)



class ConfirmReinstallView(discord.ui.View):
    def __init__(self, container_name: str, manage_cog, original_embed: discord.Embed, original_view: discord.ui.View):
        super().__init__(timeout=60)
        self.container_name = container_name
        self.manage_cog = manage_cog
        self.original_embed = original_embed
        self.original_view = original_view

    @discord.ui.button(label="Confirm Reinstall", style=discord.ButtonStyle.danger)
    async def confirm(self, button: discord.ui.Button, interaction: discord.Interaction):
        await interaction.response.send_message(f"Reinstalling {self.container_name}...", ephemeral=True)
        loop = asyncio.get_running_loop()
        new_container_name, new_ssh_link = await loop.run_in_executor(None, lxc.reinstall_container, self.container_name)
        if new_container_name and new_ssh_link:
            self.original_embed.set_field_at(index=3, name="SSH Link", value=f"```\n{new_ssh_link}\n```", inline=False)
            self.original_embed.title = f"VPS: {new_container_name}" # Update title with new container name
            await interaction.edit_original_response(content=f"{self.container_name} reinstalled successfully as {new_container_name}.", embed=self.original_embed, view=self.original_view)
        else:
            await interaction.edit_original_response(content=f"Failed to reinstall {self.container_name}.", view=None)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("Reinstallation cancelled.", ephemeral=True)

class ConfirmDeleteView(discord.ui.View):
    def __init__(self, container_name: str, manage_cog, original_embed: discord.Embed, original_view: discord.ui.View):
        super().__init__(timeout=60)
        self.container_name = container_name
        self.manage_cog = manage_cog
        self.original_embed = original_embed
        self.original_view = original_view

    @discord.ui.button(label="Confirm Delete", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(f"Stopping and deleting {self.container_name}...", ephemeral=True)
        loop = asyncio.get_running_loop()
        
        # Stop the container first
        stop_success = await loop.run_in_executor(None, lxc.stop_container, self.container_name)
        if not stop_success:
            await interaction.edit_original_response(content=f"Failed to stop {self.container_name}. Deletion aborted.", view=None)
            return

        # Destroy the container
        destroy_success = await loop.run_in_executor(None, lxc.delete_container, self.container_name)
        if destroy_success:
            # Remove from database
            db.delete_vps_by_container_name(self.container_name)
            await interaction.edit_original_response(content=f"{self.container_name} deleted successfully.", view=None)
        else:
            await interaction.edit_original_response(content=f"Failed to delete {self.container_name}.", view=None)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("Deletion cancelled.", ephemeral=True)

class PortForwardModal(discord.ui.Modal, title="Port Configuration"):
    ports_input = discord.ui.TextInput(label="Ports to Forward", placeholder="ex: 80-443-8080", required=True)

    def __init__(self, container_name: str, bot: commands.Bot, existing_forwards: list):
        super().__init__()
        self.container_name = container_name
        self.bot = bot
        self.existing_forwards = existing_forwards # Store for potential use in description or other fields

        self.title = "Configuration des Ports"

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        
        ports_str = self.ports_input.value
        ports_to_forward = [p.strip() for p in ports_str.split('-') if p.strip().isdigit()]

        if not ports_to_forward:
            await interaction.followup.send("Please enter valid port numbers separated by hyphens.", ephemeral=True)
            return

        loop = asyncio.get_running_loop()
        success_messages = []
        error_messages = []

        for port in ports_to_forward:
            try:
                # Need to get container IP here
                # For now, let's assume lxc.add_port_forward handles IP discovery
                add_success = await loop.run_in_executor(None, lxc.add_port_forward, self.container_name, port)
                if add_success:
                    success_messages.append(f"Port {port} forwarded successfully.")
                else:
                    error_messages.append(f"Failed to forward port {port}.")
            except Exception as e:
                error_messages.append(f"Error forwarding port {port}: {e}")
        
        response_description = ""
        if success_messages:
            response_description += "\n".join(success_messages)
        if error_messages:
            response_description += "\n" + "\n".join(error_messages)

        response_embed = discord.Embed(
            title="Port Forwarding Results",
            description=response_description,
            color=discord.Color.green() if not error_messages else discord.Color.red()
        )
        await interaction.followup.send(embed=response_embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(Manage(bot))