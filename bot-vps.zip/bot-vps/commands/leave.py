import discord
from discord.ext import commands
import logging
from utils.database import db
from utils import lxc

class LeaveCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        """
        Handles the event when a member leaves the server.
        This function will delete all of the user's VPS containers and reset their credits.
        """
        logging.info(f"Member {member.id} ({member.name}) has left the server. Cleaning up resources.")
        
        # Get all VPS for the user
        user_vps_list = db.get_user_vps(member.id)
        
        if user_vps_list:
            logging.info(f"Found {len(user_vps_list)} VPS for user {member.id}. Deleting them.")
            for vps in user_vps_list:
                container_name = vps['container_name']
                vps_id = vps['id']
                
                # Delete the LXC container
                if lxc.delete_container(container_name):
                    logging.info(f"Successfully deleted container {container_name} for user {member.id}.")
                    # Delete the VPS from the database
                    db.delete_vps(vps_id)
                    logging.info(f"Successfully deleted VPS record {vps_id} from database for user {member.id}.")
                else:
                    logging.error(f"Failed to delete container {container_name} for user {member.id}.")
        else:
            logging.info(f"No VPS found for user {member.id}.")

        # Set user's credits to 0
        logging.info(f"Resetting credits for user {member.id}.")
        db.set_balance(member.id, 0)
        logging.info(f"Credits for user {member.id} have been reset to 0.")

async def setup(bot):
    await bot.add_cog(LeaveCog(bot))
