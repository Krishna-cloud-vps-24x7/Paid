import discord
from discord.ext import commands, tasks
from utils.database import db
import asyncio

class MonthlyTrialView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None) # Make the view persistent

    @discord.ui.button(label="Claim 100 Free Credits", style=discord.ButtonStyle.green, custom_id="monthly_trial:claim")
    async def claim_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        user_id = interaction.user.id

        if db.has_received_monthly_trial(user_id):
            await interaction.response.send_message("You have already claimed your monthly trial credits!", ephemeral=True)
            return

        db.add_credits(user_id, 100)
        db.record_monthly_trial_receipt(user_id)
        await interaction.response.send_message("You have successfully claimed 100 free credits!", ephemeral=True)

class MonthlyTrial(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.target_channel_id = 1338196823621242950
        self.check_monthly_trial_message.start()

    def cog_unload(self):
        self.check_monthly_trial_message.cancel()

    @tasks.loop(hours=24) # Check every 24 hours
    async def check_monthly_trial_message(self):
        await self.bot.wait_until_ready()
        
        target_channel = self.bot.get_channel(self.target_channel_id)
        if not target_channel:
            print(f"Error: Could not find channel with ID {self.target_channel_id}.")
            return

        stored_message_id, stored_channel_id = db.get_monthly_trial_message_id()

        message = None
        if stored_message_id and stored_channel_id == self.target_channel_id:
            try:
                message = await target_channel.fetch_message(stored_message_id)
            except discord.NotFound:
                print(f"Monthly trial message with ID {stored_message_id} not found. Sending a new one.")
                message = None
            except discord.HTTPException as e:
                print(f"Failed to fetch monthly trial message: {e}")
                message = None

        if message is None:
            embed = discord.Embed(
                title="🎁 Monthly Free Credits! 🎁",
                description="Click the button below to claim your 100 free credits this month!",
                color=discord.Color.gold()
            )
            embed.set_footer(text="These credits can only be claimed once per user.")

            sent_message = await target_channel.send(embed=embed, view=MonthlyTrialView())
            db.save_monthly_trial_message_id(sent_message.id, sent_message.channel.id)
            print(f"New monthly trial message sent to {target_channel.name} with ID {sent_message.id}.")
        else:
            # Ensure the view is re-attached if the bot restarts and the message already exists
            # This is crucial for persistent views
            await message.edit(view=MonthlyTrialView())
            print(f"Monthly trial message found and view re-attached in {target_channel.name}.")


async def setup(bot):
    await bot.add_cog(MonthlyTrial(bot))
    # Add the persistent view to the bot if it's not already added
    # This is important for handling interactions on messages sent before bot restart
    bot.add_view(MonthlyTrialView())