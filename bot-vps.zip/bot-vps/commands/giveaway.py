
import discord
from discord.ext import tasks, commands
from utils.database import db
from datetime import datetime
import os
import aiohttp
import json
import random
import asyncio

class GiveawayView(discord.ui.View):
    def __init__(self, duration_hours):
        super().__init__(timeout=duration_hours * 3600)
        self.participants = set()

    @discord.ui.button(label="Join", style=discord.ButtonStyle.success)
    async def join_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id in self.participants:
            await interaction.response.send_message("You have already joined the giveaway.", ephemeral=True)
        else:
            self.participants.add(interaction.user.id)
            await interaction.response.send_message("You have joined the giveaway!", ephemeral=True)

    @discord.ui.button(label="Leave", style=discord.ButtonStyle.danger)
    async def leave_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id not in self.participants:
            await interaction.response.send_message("You have not joined the giveaway.", ephemeral=True)
        else:
            self.participants.remove(interaction.user.id)
            await interaction.response.send_message("You have left the giveaway.", ephemeral=True)

class Giveaway(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.giveaway_channel_id = 1338196896526762125
        self.giveaway_active = False
        self.check_giveaway.start()

    def cog_unload(self):
        self.check_giveaway.cancel()

    @tasks.loop(minutes=5)
    async def check_giveaway(self):
        await self.bot.wait_until_ready()
        if self.giveaway_active:
            return

        # Get transactions count from OxaPay API
        transactions_this_month = 0
        merchant_api_key = os.getenv("OXAPAY_MERCHANT_KEY")
        if merchant_api_key:
            now = datetime.now()
            first_day_of_month = datetime(now.year, now.month, 1)
            if now.month == 12:
                first_day_of_next_month = datetime(now.year + 1, 1, 1)
            else:
                first_day_of_next_month = datetime(now.year, now.month + 1, 1)

            start_timestamp = int(first_day_of_month.timestamp())
            end_timestamp = int(first_day_of_next_month.timestamp())

            headers = {
                'merchant_api_key': merchant_api_key,
                'Content-Type': 'application/json'
            }
            params = {
                'from_date': start_timestamp,
                'to_date': end_timestamp
            }
            async with aiohttp.ClientSession() as session:
                try:
                    async with session.get('https://api.oxapay.com/v1/payment', headers=headers, params=params) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            transactions_this_month = data.get('data', {}).get('meta', {}).get('total', 0)
                except Exception as e:
                    print(f"Error getting transactions from OxaPay: {e}")

        last_transaction_count = db.get_last_giveaway_transaction_count()

        if transactions_this_month >= last_transaction_count + 20:
            self.giveaway_active = True
            await self.start_giveaway()
            db.update_last_giveaway_transaction_count(transactions_this_month)

    async def start_giveaway(self):
        channel = self.bot.get_channel(self.giveaway_channel_id)
        if not channel:
            print(f"Giveaway channel with ID {self.giveaway_channel_id} not found.")
            self.giveaway_active = False
            return

        duration_hours = 24
        embed = discord.Embed(
            title="🎉 Giveaway! 🎉",
            description=f"A new giveaway has started! 100 credits are up for grabs!\nClick the \"Join\" button to participate.\nEnds in {duration_hours} hours.",
            color=discord.Color.gold()
        )
        view = GiveawayView(duration_hours)

        await channel.send(embed=embed, view=view)
        await asyncio.sleep(duration_hours * 3600)

        if view.participants:
            winner_id = random.choice(list(view.participants))
            winner = self.bot.get_user(winner_id)
            if winner:
                db.add_credits(winner_id, 100)
                await channel.send(f"Congratulations {winner.mention}! You won 100 credits!")
            else:
                await channel.send("Could not find the winner.")
        else:
            await channel.send("No one participated in the giveaway.")

        self.giveaway_active = False

async def setup(bot):
    await bot.add_cog(Giveaway(bot))
