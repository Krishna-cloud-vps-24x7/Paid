import sqlite3
import logging
from datetime import datetime, timedelta

class Database:
    def __init__(self, db_file):
        self.db_file = db_file
        self.init_db()

    def _execute(self, query, params=(), fetchone=False, fetchall=False, commit=False):
        with sqlite3.connect(self.db_file) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute(query, params)
            if commit:
                conn.commit()
            if fetchone:
                return cursor.fetchone()
            if fetchall:
                return cursor.fetchall()
            return None

    def get_db_connection(self):
        # This method is no longer strictly needed for external calls if _execute is used internally
        # but kept for compatibility or specific needs.
        conn = sqlite3.connect(self.db_file)
        conn.row_factory = sqlite3.Row
        return conn

    def init_db(self):
        # Use _execute for initialization as well
        self._execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                balance INTEGER NOT NULL DEFAULT 0
            )
        ''')
        self._execute('''
            CREATE TABLE IF NOT EXISTS vps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                container_name TEXT NOT NULL UNIQUE,
                cpu INTEGER NOT NULL,
                ram INTEGER NOT NULL,
                disk INTEGER NOT NULL,
                cost_credits INTEGER NOT NULL,
                due_date DATETIME NOT NULL,
                status TEXT NOT NULL DEFAULT 'active', -- active, overdue, to_delete
                ssh_link TEXT, -- New column for SSH link
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        self._execute('''
            CREATE TABLE IF NOT EXISTS transactions (
                track_id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                credits INTEGER NOT NULL,
                expiration_time TIMESTAMP NOT NULL,
                attributed BOOLEAN NOT NULL DEFAULT 0
            )
        ''')
        self._execute('''
            CREATE TABLE IF NOT EXISTS port_forwards (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                container_name TEXT NOT NULL,
                external_port INTEGER NOT NULL,
                internal_port INTEGER NOT NULL,
                protocol TEXT NOT NULL,
                device_name TEXT NOT NULL UNIQUE,
                FOREIGN KEY (container_name) REFERENCES vps(container_name) ON DELETE CASCADE,
                UNIQUE(external_port, protocol)
            )
        ''')
        self._execute('''
            CREATE TABLE IF NOT EXISTS channel_stats (
                channel_key TEXT PRIMARY KEY,
                channel_id INTEGER
            )
        ''')
        self._execute('''
            CREATE TABLE IF NOT EXISTS giveaway_stats (
                id INTEGER PRIMARY KEY,
                last_transaction_count INTEGER NOT NULL DEFAULT 0
            )
        ''')
        self._execute('''
            CREATE TABLE IF NOT EXISTS monthly_trial_users (
                user_id INTEGER PRIMARY KEY
            )
        ''')
        self._execute('''
            CREATE TABLE IF NOT EXISTS monthly_trial_message (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                message_id INTEGER NOT NULL,
                channel_id INTEGER NOT NULL
            )
        ''')

        # Check and add 'attributed' column to 'transactions' table for migration
        with sqlite3.connect(self.db_file) as conn:
            conn.row_factory = sqlite3.Row # Add this line
            cursor = conn.cursor()
            cursor.execute("PRAGMA table_info(transactions)")
            columns = [column['name'] for column in cursor.fetchall()]
            if 'attributed' not in columns:
                self._execute("ALTER TABLE transactions ADD COLUMN attributed BOOLEAN NOT NULL DEFAULT 0", commit=True)
                logging.info("Database migration: Added 'attributed' column to 'transactions' table.")

        # Check and add 'ssh_link' column to 'vps' table for migration
        with sqlite3.connect(self.db_file) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("PRAGMA table_info(vps)")
            columns = [column['name'] for column in cursor.fetchall()]
            if 'ssh_link' not in columns:
                self._execute("ALTER TABLE vps ADD COLUMN ssh_link TEXT", commit=True)
                logging.info("Database migration: Added 'ssh_link' column to 'vps' table.")

        logging.info("Database initialized.")

    def get_balance(self, user_id):
        result = self._execute("SELECT balance FROM users WHERE user_id = ?", (user_id,), fetchone=True)
        return result['balance'] if result else 0

    def add_credits(self, user_id, amount):
        self._execute("INSERT OR IGNORE INTO users (user_id, balance) VALUES (?, 0)", (user_id,), commit=True)
        self._execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amount, user_id), commit=True)

    def set_balance(self, user_id, amount):
        self._execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,), commit=True)
        self._execute("UPDATE users SET balance = ? WHERE user_id = ?", (amount, user_id), commit=True)
        logging.info(f"User {user_id}'s balance set to {amount}.")

    def add_vps(self, user_id, container_name, cpu, ram, disk, cost_credits):
        due_date = datetime.now() + timedelta(days=30)
        self._execute(
            "INSERT INTO vps (user_id, container_name, cpu, ram, disk, cost_credits, due_date) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (user_id, container_name, cpu, ram, disk, cost_credits, due_date),
            commit=True
        )
        # No direct way to get lastrowid with _execute without returning cursor, so we'll omit for now
        # or add a fetch_lastrowid option if needed.
        logging.info(f"VPS added for user {user_id} with container {container_name}")

    def get_user_vps(self, user_id):
        return self._execute("SELECT * FROM vps WHERE user_id = ?", (user_id,), fetchall=True)

    def get_all_vps(self):
        return self._execute("SELECT * FROM vps", fetchall=True)

    def get_vps_by_id(self, vps_id):
        return self._execute("SELECT * FROM vps WHERE id = ?", (vps_id,), fetchone=True)

    def get_vps_by_container_name(self, container_name):
        return self._execute("SELECT * FROM vps WHERE container_name = ?", (container_name,), fetchone=True)

    def update_vps_due_date(self, vps_id):
        new_due_date = datetime.now() + timedelta(days=30)
        self._execute("UPDATE vps SET due_date = ?, status = 'active' WHERE id = ?", (new_due_date, vps_id), commit=True)
        logging.info(f"VPS {vps_id} renewed. New due date: {new_due_date}")

    def extend_vps_due_date(self, vps_id, months):
        vps = self.get_vps_by_id(vps_id)
        if vps:
            current_due_date = datetime.strptime(vps['due_date'], '%Y-%m-%d %H:%M:%S.%f')
            new_due_date = current_due_date + timedelta(days=30 * months)
            self._execute("UPDATE vps SET due_date = ?, status = 'active' WHERE id = ?", (new_due_date, vps_id), commit=True)
            logging.info(f"VPS {vps_id} renewed for {months} months. New due date: {new_due_date}")

    def update_vps_status(self, vps_id, status):
        self._execute("UPDATE vps SET status = ? WHERE id = ?", (status, vps_id), commit=True)
        logging.info(f"VPS {vps_id} status updated to {status}")

    def delete_vps(self, vps_id):
        vps_info = self.get_vps_by_id(vps_id)
        if vps_info:
            self._execute("DELETE FROM vps WHERE id = ?", (vps_id,), commit=True)
            logging.info(f"VPS {vps_id} ({vps_info['container_name']}) deleted from database.")
            return vps_info['container_name']
        return None

    def delete_vps_by_container_name(self, container_name):
        vps_info = self.get_vps_by_container_name(container_name)
        if vps_info:
            self._execute("DELETE FROM vps WHERE container_name = ?", (container_name,), commit=True)
            logging.info(f"VPS ({container_name}) deleted from database.")
            return vps_info['container_name']
        return None

    def update_vps_ssh_link(self, container_name, ssh_link):
        self._execute("UPDATE vps SET ssh_link = ? WHERE container_name = ?", (ssh_link, container_name), commit=True)
        logging.info(f"VPS {container_name} SSH link updated.")

    # New functions for transactions
    def add_transaction(self, track_id, user_id, credits, expiration_time):
        self._execute(
            "INSERT INTO transactions (track_id, user_id, credits, expiration_time) VALUES (?, ?, ?, ?)",
            (track_id, user_id, credits, expiration_time),
            commit=True
        )

    def get_unattributed_transactions(self):
        return self._execute("SELECT track_id, user_id, credits, expiration_time, attributed FROM transactions WHERE attributed = 0", fetchall=True)

    def mark_transaction_as_attributed(self, track_id):
        self._execute("UPDATE transactions SET attributed = 1 WHERE track_id = ?", (track_id,), commit=True)

    def add_port_forward_entry(self, container_name, external_port, internal_port, protocol, device_name):
        self._execute(
            "INSERT INTO port_forwards (container_name, external_port, internal_port, protocol, device_name) VALUES (?, ?, ?, ?, ?)",
            (container_name, external_port, internal_port, protocol, device_name),
            commit=True
        )
        logging.info(f"Port forward {external_port}:{internal_port}/{protocol} added for {container_name}.")

    def remove_port_forward_entry(self, device_name):
        self._execute("DELETE FROM port_forwards WHERE device_name = ?", (device_name,), commit=True)
        logging.info(f"Port forward device {device_name} removed from database.")

    def get_port_forward_by_external_port(self, external_port, protocol):
        return self._execute("SELECT * FROM port_forwards WHERE external_port = ? AND protocol = ?", (external_port, protocol), fetchone=True)

    def get_port_forwards_for_container(self, container_name):
        return self._execute("SELECT * FROM port_forwards WHERE container_name = ?", (container_name,), fetchall=True)

    def get_transactions_this_month(self):
        now = datetime.now()
        first_day_of_month = datetime(now.year, now.month, 1)
        if now.month == 12:
            first_day_of_next_month = datetime(now.year + 1, 1, 1)
        else:
            first_day_of_next_month = datetime(now.year, now.month + 1, 1)

        start_timestamp = int(first_day_of_month.timestamp())
        end_timestamp = int(first_day_of_next_month.timestamp())

        result = self._execute(
            "SELECT COUNT(*) FROM transactions WHERE expiration_time >= ? AND expiration_time < ?",
            (start_timestamp, end_timestamp),
            fetchone=True
        )
        return result[0] if result else 0

    def get_stats_channel_id(self, key):
        result = self._execute("SELECT channel_id FROM channel_stats WHERE channel_key = ?", (key,), fetchone=True)
        return result['channel_id'] if result else None

    def set_stats_channel_id(self, key, channel_id):
        self._execute(
            "INSERT OR REPLACE INTO channel_stats (channel_key, channel_id) VALUES (?, ?)",
            (key, channel_id),
            commit=True
        )

    def delete_stats_channel(self, key):
        self._execute("DELETE FROM channel_stats WHERE channel_key = ?", (key,), commit=True)

    def get_last_giveaway_transaction_count(self):
        result = self._execute("SELECT last_transaction_count FROM giveaway_stats WHERE id = 1", fetchone=True)
        if result is None:
            self._execute("INSERT INTO giveaway_stats (id, last_transaction_count) VALUES (1, 0)", commit=True)
            return 0
        return result['last_transaction_count']

    def record_monthly_trial_receipt(self, user_id):
        self._execute("INSERT OR IGNORE INTO monthly_trial_users (user_id) VALUES (?)", (user_id,), commit=True)
        logging.info(f"User {user_id} recorded as having received monthly trial credits.")

    def has_received_monthly_trial(self, user_id):
        result = self._execute("SELECT user_id FROM monthly_trial_users WHERE user_id = ?", (user_id,), fetchone=True)
        return result is not None

    def save_monthly_trial_message_id(self, message_id, channel_id):
        self._execute("INSERT OR REPLACE INTO monthly_trial_message (id, message_id, channel_id) VALUES (1, ?, ?)", (message_id, channel_id), commit=True)
        logging.info(f"Monthly trial message ID {message_id} saved for channel {channel_id}.")

    def get_monthly_trial_message_id(self):
        result = self._execute("SELECT message_id, channel_id FROM monthly_trial_message WHERE id = 1", fetchone=True)
        return result if result else (None, None)

db = Database("database.db")
