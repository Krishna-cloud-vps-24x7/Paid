import subprocess
import time
import logging
import uuid
import re
import yaml
from utils.database import db

logging.basicConfig(level=logging.INFO)

def setup_zfs_storage():
    """Configures the ZFS storage pool for containers if necessary"""
    try:
        # Check if the pool already exists
        result = subprocess.run(
            ["lxc", "storage", "list", "--format", "csv"],
            capture_output=True,
            text=True
        )
        if "bot-storage" in result.stdout:
            logging.info("ZFS storage pool already exists")
            return True
            
        # Create the ZFS storage pool
        logging.info("Creating ZFS storage pool...")
        subprocess.run(
            ["lxc", "storage", "create", "bot-storage", "zfs", "size=500GB"],
            check=True,
            capture_output=True,
            text=True
        )
        logging.info("ZFS storage pool created successfully")
        return True
    except subprocess.CalledProcessError as e:
        logging.error(f"Failed to setup ZFS storage: {e.stderr}")
        return False

def block_mining_pools(container_name):
    """Blocks access to mining pools via iptables in the container"""
    mining_pools = [
        # Popular pools
        "pool.supportxmr.com",
        "xmr-eu1.nanopool.org",
        "xmr-us-east1.nanopool.org",
        "pool.minexmr.com",
        "gulf.moneroocean.stream",
        "mine.xmrpool.net",
        "pool.hashvault.pro",
        "xmr.pool.minergate.com",
        # Ethereum pools
        "eth.2miners.com",
        "eth-eu1.nanopool.org",
        # Common mining ports
    ]
    
    mining_ports = [3333, 4444, 5555, 7777, 8888, 9999, 14444, 45700]
    
    try:
        # Install iptables in the container
        subprocess.run(
            ["lxc", "exec", container_name, "--", "apt-get", "install", "-y", "iptables"],
            capture_output=True,
            timeout=60
        )
        
        # Block mining pool domains
        for pool in mining_pools:
            subprocess.run(
                ["lxc", "exec", container_name, "--", 
                 "iptables", "-A", "OUTPUT", "-d", pool, "-j", "DROP"],
                capture_output=True
            )
        
        # Block common mining ports
        for port in mining_ports:
            subprocess.run(
                ["lxc", "exec", container_name, "--",
                 "iptables", "-A", "OUTPUT", "-p", "tcp", "--dport", str(port), "-j", "DROP"],
                capture_output=True
            )
            subprocess.run(
                ["lxc", "exec", container_name, "--",
                 "iptables", "-A", "OUTPUT", "-p", "udp", "--dport", str(port), "-j", "DROP"],
                capture_output=True
            )
        
        # Make rules persistent
        subprocess.run(
            ["lxc", "exec", container_name, "--",
             "sh", "-c", "iptables-save > /etc/iptables.rules"],
            capture_output=True
        )
        
        logging.info(f"Mining pool blocking configured for {container_name}")
        return True
    except Exception as e:
        logging.error(f"Failed to block mining pools: {e}")
        return False

def wait_for_network(container_name, timeout=60):
    """Waits for the container to have a network connection"""
    start = time.time()
    while time.time() - start < timeout:
        try:
            result = subprocess.run(
                ["lxc", "exec", container_name, "--", "ping", "-c", "1", "8.8.8.8"],
                capture_output=True,
                timeout=5
            )
            if result.returncode == 0:
                logging.info(f"Network ready for {container_name}")
                return True
        except subprocess.TimeoutExpired:
            pass
        time.sleep(2)
    return False

def _get_cpu_assignment(cpu_request):
    """
    Determines the CPU core assignment based on the user's request and current load.
    - If cpu_request > 1, it pins to a range of cores (0, 1, ...).
    - If cpu_request == 1, it finds the least loaded core among cores 0-3.
    """
    CORE_POOL_SIZE = 4 # Cores 0, 1, 2, 3
    
    # If user wants more than one core, pin to a range starting from 0
    if cpu_request > 1:
        # Clamp to the max number of cores in the pool
        num_cores = min(cpu_request, CORE_POOL_SIZE)
        core_list = list(range(num_cores))
        return ",".join(map(str, core_list))

    # If user wants a single core, find the least loaded one in the pool
    try:
        result = subprocess.run(
            ["lxc", "list", "--format", "yaml"],
            check=True, capture_output=True, text=True
        )
        containers = yaml.safe_load(result.stdout)
        
        core_counts = {i: 0 for i in range(CORE_POOL_SIZE)}
        
        if containers: # Ensure containers is not None
            for container in containers:
                # The config might not exist for all containers
                config = container.get('config', {})
                cpu_limit = config.get('limits.cpu')
                
                # We only care about containers pinned to a single core
                if cpu_limit and cpu_limit.isdigit():
                    core = int(cpu_limit)
                    if core in core_counts:
                        core_counts[core] += 1
        
        # Find the core with the minimum number of containers
        least_loaded_core = min(core_counts, key=core_counts.get)
        
        # Check if the least loaded core is already at capacity
        if core_counts[least_loaded_core] >= 20:
            logging.warning(
                f"Core {least_loaded_core} is at or over capacity (20 containers). "
                f"Assigning new container anyway."
            )
            
        return str(least_loaded_core)

    except (subprocess.CalledProcessError, FileNotFoundError, yaml.YAMLError) as e:
        logging.error(f"Failed to determine CPU core assignment: {e}. Defaulting to core 0.")
        # Fallback in case of any error
        return "0"

def create_lxc_container(user_id, username, cpu, ram, disk):
    """
    Creates an LXC container with specified resources and returns the tmate SSH link.
    Uses ZFS for reliable disk limiting.
    """
    container_name = f"{username}-{user_id}-{str(uuid.uuid4())[:8]}"
    # Sanitize username for container name (LXC names have restrictions)
    # Allow only alphanumeric characters and hyphens
    sanitized_username = re.sub(r'[^a-z0-9-]', '', username.lower().replace(" ", "-"))
    container_name = f"{sanitized_username}-{user_id}-{str(uuid.uuid4())[:8]}"
    
    # Ensure ZFS storage pool exists
    if not setup_zfs_storage():
        logging.error("Failed to setup ZFS storage pool")
        return None, None
    
    try:
        logging.info(f"Creating container {container_name} for user {user_id}")
        logging.info(f"Resources: {cpu} CPU, {ram}GB RAM, {disk}GB disk")
        
        # Determine CPU pinning strategy
        cpu_assignment = _get_cpu_assignment(cpu)
        logging.info(f"Assigning container to CPU core(s): {cpu_assignment}")

        # Create the container with ZFS storage pool and resource limits
        # CPU pinning is applied after launch
        launch_cmd = [
            "lxc", "launch", "ubuntu:22.04", container_name,
            "--storage", "bot-storage",
            "--config", f"limits.cpu={cpu}",
            "--config", f"limits.memory={ram}GB",
            "--config", "security.nesting=false",
            "--config", "security.privileged=false",
            # Process limits to prevent fork bombs
            "--config", "limits.processes=500"
        ]
        
        result = subprocess.run(launch_cmd, check=True, capture_output=True, text=True)
        logging.info(f"Container {container_name} launched")

        # Apply CPU pinning
        try:
            subprocess.run(
                ["lxc", "config", "set", container_name, "limits.cpu", cpu_assignment],
                check=True,
                capture_output=True,
                text=True
            )
            logging.info(f"Applied CPU assignment '{cpu_assignment}' to {container_name}")
        except subprocess.CalledProcessError as e:
            logging.error(f"Failed to set CPU config: {e.stderr}")
            raise # Re-raise to trigger cleanup

        # Apply ZFS disk quota
        try:
            subprocess.run(
                ["lxc", "config", "device", "set", container_name, "root", "size", f"{disk}GB"],
                check=True,
                capture_output=True,
                text=True
            )
            logging.info(f"Disk quota of {disk}GB set for {container_name}")
        except subprocess.CalledProcessError as e:
            logging.error(f"Failed to set disk quota: {e.stderr}")
            raise # Re-raise to trigger cleanup

        # Wait for network to be available
        if not wait_for_network(container_name):
            raise Exception(f"Network timeout for {container_name}")

        # Update and install packages
        logging.info(f"Installing packages in {container_name}...")
        
        commands = [
            ["lxc", "exec", container_name, "--", "apt-get", "update"],
            ["lxc", "exec", container_name, "--", "apt-get", "install", "-y", "tmate"],
        ]
        
        for cmd in commands:
            subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=120)
        
        logging.info(f"Packages installed in {container_name}")

        # Block access to mining pools
        block_mining_pools(container_name)

        # Start tmate and get SSH link
        logging.info(f"Starting tmate in {container_name}...")
        tmate_socket = f"/tmp/tmate-{container_name}.sock"
        
        # Start tmate in background
        start_tmate_cmd = [
            "lxc", "exec", container_name, "--",
            "tmate", "-S", tmate_socket, "new-session", "-d"
        ]
        subprocess.run(start_tmate_cmd, check=True, capture_output=True, text=True)

        # Wait for tmate to be ready
        wait_tmate_cmd = [
            "lxc", "exec", container_name, "--",
            "tmate", "-S", tmate_socket, "wait", "tmate-ready"
        ]
        subprocess.run(wait_tmate_cmd, check=True, capture_output=True, text=True, timeout=30)

        # Get SSH link
        get_ssh_cmd = [
            "lxc", "exec", container_name, "--",
            "tmate", "-S", tmate_socket, "display", "-p", "#{tmate_ssh}"
        ]
        result = subprocess.run(get_ssh_cmd, check=True, capture_output=True, text=True)
        ssh_link = result.stdout.strip()
        
        logging.info(f"Container {container_name} created successfully")
        logging.info(f"SSH link: {ssh_link}")

        # Add VPS to database
        db.add_vps(user_id, container_name, cpu, ram, disk, 0)
        db.update_vps_ssh_link(container_name, ssh_link)
        
        return container_name, ssh_link

    except subprocess.CalledProcessError as e:
        logging.error(f"Command failed for {container_name}: {e.stderr}")
        cleanup_container(container_name)
        return None, None
    except Exception as e:
        logging.error(f"Error creating container {container_name}: {str(e)}")
        cleanup_container(container_name)
        return None, None

def cleanup_container(container_name):
    """Deletes a container in case of error"""
    try:
        logging.info(f"Cleaning up container {container_name}")
        subprocess.run(
            ["lxc", "delete", container_name, "--force"],
            capture_output=True,
            timeout=30
        )
        logging.info(f"Container {container_name} deleted")
    except Exception as e:
        logging.error(f"Failed to cleanup {container_name}: {e}")

def delete_container(container_name):
    """Gracefully deletes a container"""
    try:
        # Stop first
        subprocess.run(
            ["lxc", "stop", container_name],
            capture_output=True,
            timeout=30
        )
        time.sleep(2)
        # Then delete
        subprocess.run(
            ["lxc", "delete", container_name],
            check=True,
            capture_output=True,
            timeout=30
        )
        logging.info(f"Container {container_name} deleted successfully")
        return True
    except Exception as e:
        logging.error(f"Error deleting {container_name}: {e}")
        return False

def list_user_containers(user_id):
    """Lists all containers for a user"""
    try:
        result = subprocess.run(
            ["lxc", "list", "--format", "csv", "-c", "n"],
            check=True,
            capture_output=True,
            text=True
        )
        all_containers = result.stdout.strip().split('\n')
        user_containers = [
            c for c in all_containers 
            if f"-{user_id}-" in c # More robust check for user_id in container name
        ]
        return user_containers
    except Exception as e:
        logging.error(f"Error listing containers: {e}")
        return []

def get_container_info(container_name):
    """Retrieves container information"""
    try:
        result = subprocess.run(
            ["lxc", "info", container_name],
            check=True,
            capture_output=True,
            text=True
        )
        return result.stdout
    except Exception as e:
        logging.error(f"Error getting container info: {e}")
        return None

def stop_container(container_name):
    """Stops an LXC container."""
    try:
        # Check if the container is already stopped
        status_result = subprocess.run(["lxc", "list", container_name, "--format", "csv", "-c", "s"], capture_output=True, text=True)
        if "STOPPED" in status_result.stdout.strip().upper():
            logging.info(f"Container {container_name} is already stopped.")
            return True

        subprocess.run(["lxc", "stop", container_name], check=True, capture_output=True, text=True)
        logging.info(f"Container {container_name} stopped.")
        return True
    except subprocess.CalledProcessError as e:
        logging.error(f"Failed to stop container {container_name}: {e.stderr}")
        return False

def start_container(container_name):
    """Starts an LXC container."""
    try:
        # Check if the container is already running
        status_result = subprocess.run(["lxc", "list", container_name, "--format", "csv", "-c", "s"], capture_output=True, text=True)
        if "RUNNING" in status_result.stdout.strip().upper():
            logging.info(f"Container {container_name} is already running.")
            return None # Indicate already running

        subprocess.run(["lxc", "start", container_name], check=True, capture_output=True, text=True)
        logging.info(f"Container {container_name} started.")
        return True # Indicate started successfully
    except subprocess.CalledProcessError as e:
        logging.error(f"Failed to start container {container_name}: {e.stderr}")
        return False # Indicate failed to start

def regenerate_ssh_link(container_name):
    """Regenerates the SSH link for a given container using tmate."""
    try:
        logging.info(f"Regenerating SSH link for {container_name}...")
        tmate_socket = f"/tmp/tmate-{container_name}.sock"

        # Kill any existing tmate sessions
        subprocess.run(
            ["lxc", "exec", container_name, "--", "tmate", "-S", tmate_socket, "kill-session"],
            capture_output=True
        )

        # Start a new tmate session in the background
        start_tmate_cmd = [
            "lxc", "exec", container_name, "--",
            "tmate", "-S", tmate_socket, "new-session", "-d"
        ]
        subprocess.run(start_tmate_cmd, check=True, capture_output=True, text=True)

        # Wait for tmate to be ready
        wait_tmate_cmd = [
            "lxc", "exec", container_name, "--",
            "tmate", "-S", tmate_socket, "wait", "tmate-ready"
        ]
        subprocess.run(wait_tmate_cmd, check=True, capture_output=True, text=True, timeout=30)

        # Get the new SSH link
        get_ssh_cmd = [
            "lxc", "exec", container_name, "--",
            "tmate", "-S", tmate_socket, "display", "-p", "#{tmate_ssh}"
        ]
        result = subprocess.run(get_ssh_cmd, check=True, capture_output=True, text=True)
        ssh_link = result.stdout.strip()

        logging.info(f"New SSH link for {container_name}: {ssh_link}")
        return ssh_link
    except subprocess.CalledProcessError as e:
        logging.error(f"Failed to regenerate SSH link for {container_name}: {e.stderr}")
        return None
    except Exception as e:
        logging.error(f"Error regenerating SSH link for {container_name}: {str(e)}")
        return None

def list_port_forwards(container_name):
    """Lists existing port forwarding rules for a container from the database."""
    try:
        forwards_db = db.get_port_forwards_for_container(container_name)
        forwards = []
        for f in forwards_db:
            forwards.append(f"{f['external_port']}/{f['protocol']} -> {f['internal_port']}")
        return forwards
    except Exception as e:
        logging.error(f"Error listing port forwards for {container_name} from DB: {e}")
        return []

def add_port_forward(container_name, port):
    """Adds a port forwarding rule to an LXC container."""
    try:
        # Check if port is already forwarded globally
        if db.get_port_forward_by_external_port(int(port), 'tcp'):
            logging.error(f"Port {port} is already forwarded on another container.")
            return False

        # Get container IP address
        info_raw = get_container_info(container_name)
        if not info_raw:
            logging.error(f"Could not get info for {container_name} to add port forward.")
            return False

        ip_match = re.search(r"inet:\s*([0-9.]+)/\d+\s*\(global\)", info_raw)
        if not ip_match:
            logging.error(f"Could not find IP address for {container_name} to add port forward.")
            return False
        container_ip = ip_match.group(1)

        device_name = f"proxy{port}"
        listen_arg = f"listen=tcp:0.0.0.0:{port}"
        connect_arg = f"connect=tcp:{container_ip}:{port}"

        subprocess.run(
            ["lxc", "config", "device", "add", container_name, device_name, "proxy",
             listen_arg, connect_arg],
            check=True,
            capture_output=True,
            text=True
        )
        logging.info(f"Port {port} forwarded for {container_name} to {container_ip}:{port}")
        
        # Add entry to database
        db.add_port_forward_entry(container_name, int(port), int(port), 'tcp', device_name)
        
        return True
    except subprocess.CalledProcessError as e:
        logging.error(f"Failed to add port forward for {container_name} port {port}: {e.stderr}")
        return False
    except Exception as e:
        logging.error(f"Error adding port forward for {container_name} port {port}: {e}")
        return False