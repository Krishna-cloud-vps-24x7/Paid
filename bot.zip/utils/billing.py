import logging
from utils.database import db
from utils import lxc
import discord

async def try_renew_vps(bot, user_id):
    user_vps = db.get_user_vps(user_id)
    user_balance = db.get_balance(user_id)
    user = None
    try:
        user = await bot.fetch_user(user_id)
    except discord.NotFound:
        pass # user not found, can't send DM

    for vps in user_vps:
        if vps['status'] == 'overdue':
            cost = vps['cost_credits']
            if user_balance >= cost:
                db.add_credits(user_id, -cost)
                user_balance -= cost
                db.update_vps_due_date(vps['id'])
                lxc.start_container(vps['container_name'])
                logging.info(f"Overdue VPS {vps['container_name']} for user {user_id} has been renewed and started.")
                if user:
                    try:
                        embed = discord.Embed(title="VPS Renewed", description=f"Your overdue VPS `{vps['container_name']}` has been renewed and is starting.", color=discord.Color.green())
                        await user.send(embed=embed)
                    except discord.Forbidden:
                        pass
