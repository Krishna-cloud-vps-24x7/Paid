import subprocess
import time
import logging
import uuid
import re
import yaml
import secrets
import string
from utils.database import db
import asyncio

logging.basicConfig(level=logging.INFO)

def generate_password(length=30):
    """Génère un mot de passe aléatoire sécurisé"""
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
    return ''.join(secrets.choice(alphabet) for _ in range(length))

async def get_available_ssh_port():
    """Trouve un port SSH disponible entre 9000 et 10000"""
    used_ports = db.get_all_ssh_ports()
    for port in range(9000, 10001):
        if port not in used_ports:
            return port
    return None

async def setup_zfs_storage():
    """Configures the ZFS storage pool for containers if necessary"""
    try:
        proc = await asyncio.create_subprocess_exec(
            "lxc", "storage", "list", "--format", "csv",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, _ = await proc.communicate()
        if "bot-storage" in stdout.decode():
            logging.info("ZFS storage pool already exists")
            return True
            
        logging.info("Creating ZFS storage pool...")
        proc = await asyncio.create_subprocess_exec(
            "lxc", "storage", "create", "bot-storage", "zfs", "size=500GB",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        _, stderr = await proc.communicate()
        if proc.returncode != 0:
            raise subprocess.CalledProcessError(proc.returncode, "lxc storage create", stderr=stderr)
        logging.info("ZFS storage pool created successfully")
        return True
    except subprocess.CalledProcessError as e:
        logging.error(f"Failed to setup ZFS storage: {e.stderr.decode()}")
        return False

async def wait_for_network(container_name, timeout=60):
    """Waits for the container to have a network connection"""
    start = time.time()
    while time.time() - start < timeout:
        try:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "exec", container_name, "--", "ping", "-c", "1", "8.8.8.8",
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL
            )
            await asyncio.wait_for(proc.wait(), timeout=5)
            if proc.returncode == 0:
                logging.info(f"Network ready for {container_name}")
                return True
        except asyncio.TimeoutError:
            pass
        await asyncio.sleep(2)
    return False

async def wait_for_ip_address(container_name, timeout=90):
    """Waits for the container to get an IP address"""
    start = time.time()
    attempt = 0
    while time.time() - start < timeout:
        attempt += 1
        try:
            # Try multiple methods to get IP
            # Method 1: Using 'ip -4 a show eth0'
            proc = await asyncio.create_subprocess_exec(
                "lxc", "exec", container_name, "--", "ip", "-4", "a", "show", "eth0",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
            
            if proc.returncode == 0:
                output = stdout.decode()
                match = re.search(r"inet\s+([0-9.]+)/", output)
                if match:
                    ip = match.group(1)
                    if ip and not ip.startswith("127."):
                        logging.info(f"Found IP {ip} for {container_name} (attempt {attempt})")
                        return ip
            
            # Method 2: Using 'hostname -I'
            proc = await asyncio.create_subprocess_exec(
                "lxc", "exec", container_name, "--", "hostname", "-I",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
            
            if proc.returncode == 0:
                ips = stdout.decode().strip().split()
                for ip in ips:
                    if ip and not ip.startswith("127.") and ":" not in ip:  # Exclude localhost and IPv6
                        logging.info(f"Found IP {ip} for {container_name} using hostname -I (attempt {attempt})")
                        return ip
            
            logging.warning(f"Attempt {attempt}: No IP address found for {container_name}. Waiting...")
            
        except Exception as e:
            logging.warning(f"Attempt {attempt}: Error getting IP for {container_name}: {e}")
        
        await asyncio.sleep(3)
    
    logging.error(f"No IP address found for {container_name} after {timeout}s")
    return None

async def check_ipv6_disabled(container_name):
    """Vérifie si IPv6 est déjà désactivé dans le conteneur"""
    try:
        proc = await asyncio.create_subprocess_exec(
            "lxc", "exec", container_name, "--", "sysctl", "-n", "net.ipv6.conf.all.disable_ipv6",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, _ = await proc.communicate()
        return stdout.decode().strip() == "1"
    except Exception:
        return False

async def _get_cpu_assignment(cpu_request):
    """Determines CPU core assignment based on request and current load"""
    CORE_POOL_SIZE = 5
    
    if cpu_request > 1:
        num_cores = min(cpu_request, CORE_POOL_SIZE)
        core_list = list(range(num_cores))
        return ",".join(map(str, core_list))

    try:
        proc = await asyncio.create_subprocess_exec(
            "lxc", "list", "--format", "yaml",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            raise subprocess.CalledProcessError(proc.returncode, "lxc list", stderr=stderr)

        containers = yaml.safe_load(stdout)
        core_counts = {i: 0 for i in range(CORE_POOL_SIZE)}
        
        if containers:
            for container in containers:
                config = container.get('config', {})
                cpu_limit = config.get('limits.cpu')
                
                if cpu_limit and cpu_limit.isdigit():
                    core = int(cpu_limit)
                    if core in core_counts:
                        core_counts[core] += 1
        
            if cpu_request == 1:
                return "1"
    except (subprocess.CalledProcessError, FileNotFoundError, yaml.YAMLError) as e:
        logging.error(f"Failed to determine CPU core assignment: {e}. Defaulting to core 0.")
        return "0"

async def create_lxc_container(user_id, username, cpu, ram, disk):
    """
    Creates an LXC container with OpenSSH access
    Returns: (container_name, ssh_connection_string, ssh_port, ssh_password)
    """
    sanitized_username = re.sub(r'[^a-z0-9-]', '', username.lower().replace(" ", "-"))
    container_name = f"{sanitized_username}-{user_id}-{str(uuid.uuid4())[:8]}"
    
    if not await setup_zfs_storage():
        logging.error("Failed to setup ZFS storage pool")
        return None, None, None, None
    
    # Trouver un port SSH disponible
    ssh_port = await get_available_ssh_port()
    if not ssh_port:
        logging.error("No available SSH ports in range 9000-10000")
        return None, None, None, None
    
    # Générer un mot de passe
    ssh_password = generate_password()
    
    try:
        logging.info(f"Creating container {container_name} for user {user_id}")
        logging.info(f"Resources: {cpu} CPU, {ram}GB RAM, {disk}GB disk")
        logging.info(f"SSH Port: {ssh_port}")
        
        cpu_assignment = await _get_cpu_assignment(cpu)
        logging.info(f"Assigning container to CPU core(s): {cpu_assignment}")

        # Clone template
        clone_cmd = ["lxc", "copy", "template-ubuntu-2204", container_name, "--storage", "bot-storage"]
        proc = await asyncio.create_subprocess_exec(*clone_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        _, stderr = await proc.communicate()
        if proc.returncode != 0: 
            raise subprocess.CalledProcessError(proc.returncode, clone_cmd, stderr=stderr)
        logging.info(f"Container {container_name} cloned from template")

        # Check if eth0 already exists before adding
        proc = await asyncio.create_subprocess_exec(
            "lxc", "config", "device", "show", container_name,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        stdout, _ = await proc.communicate()
        devices = yaml.safe_load(stdout.decode()) if stdout else {}
        
        if 'eth0' not in devices:
            # Add network interface
            proc = await asyncio.create_subprocess_exec(
                "lxc", "config", "device", "add", container_name, "eth0", "nic", 
                "name=eth0", "network=lxdbr0",
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                logging.warning(f"Failed to add eth0 device: {stderr.decode().strip()}")
            else:
                logging.info(f"eth0 device added to {container_name}")
        else:
            logging.info(f"eth0 already exists for {container_name}")

        # Apply resource limits
        try:
            proc = await asyncio.create_subprocess_exec("lxc", "config", "set", container_name, "limits.cpu", cpu_assignment, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await proc.communicate()
            
            ram_in_mb = int(ram * 1000)
            proc = await asyncio.create_subprocess_exec("lxc", "config", "set", container_name, "limits.memory", f"{ram_in_mb}MB", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await proc.communicate()
            
            proc = await asyncio.create_subprocess_exec("lxc", "config", "set", container_name, "security.nesting", "false", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await proc.communicate()
            
            proc = await asyncio.create_subprocess_exec("lxc", "config", "set", container_name, "security.privileged", "false", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await proc.communicate()
            
            proc = await asyncio.create_subprocess_exec("lxc", "config", "set", container_name, "limits.processes", "500", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await proc.communicate()
            
            logging.info(f"Resource limits configured for {container_name}")
        except subprocess.CalledProcessError as e:
            logging.error(f"Failed to set resource limits: {e.stderr.decode()}")
            raise

        # Start container
        start_cmd = ["lxc", "start", container_name]
        proc = await asyncio.create_subprocess_exec(*start_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        await proc.communicate()
        if proc.returncode != 0:
            raise subprocess.CalledProcessError(proc.returncode, start_cmd)
        logging.info(f"Container {container_name} started")

        # Wait for container to fully boot
        logging.info(f"Waiting for {container_name} to fully initialize...")
        await asyncio.sleep(10)

        # Apply disk quota
        try:
            disk_in_mb = int(disk * 1000) + 300
            proc = await asyncio.create_subprocess_exec("lxc", "config", "device", "set", container_name, "root", "size", f"{disk_in_mb}MB", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await proc.communicate()
            logging.info(f"Disk quota of {disk_in_mb}MB set for {container_name}")
        except subprocess.CalledProcessError as e:
            logging.error(f"Failed to set disk quota: {e.stderr.decode()}")
            raise

        # Wait for network
        if not await wait_for_network(container_name):
            raise Exception(f"Network timeout for {container_name}")

        # Vérifier si IPv6 est déjà désactivé
        ipv6_already_disabled = await check_ipv6_disabled(container_name)
        
        if not ipv6_already_disabled:
            logging.info(f"Disabling IPv6 for {container_name}")
            # Configure DNS
            dns_cmd = """
rm -f /etc/resolv.conf
echo "nameserver 1.1.1.1" > /etc/resolv.conf
echo "nameserver 8.8.8.8" >> /etc/resolv.conf
"""
            proc = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "bash", "-c", dns_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await asyncio.wait_for(proc.communicate(), timeout=10)

            # Configure hostname
            proc = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "bash", "-c", f"echo '{container_name}' > /etc/hostname", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await asyncio.wait_for(proc.communicate(), timeout=10)
            
            proc = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "bash", "-c", f"sed -i 's/127.0.1.1.*/127.0.1.1\t{container_name}/' /etc/hosts", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await asyncio.wait_for(proc.communicate(), timeout=10)

            # Disable IPv6
            ipv6_disable_cmd = """
cat >> /etc/sysctl.conf << 'EOF'
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1
net.ipv6.conf.lo.disable_ipv6 = 1
EOF
sysctl -w net.ipv6.conf.all.disable_ipv6=1
sysctl -w net.ipv6.conf.default.disable_ipv6=1
sysctl -w net.ipv6.conf.lo.disable_ipv6=1
echo 'Acquire::ForceIPv4 "true";' > /etc/apt/apt.conf.d/99force-ipv4
echo 'precedence ::ffff:0:0/96  100' >> /etc/gai.conf
systemctl disable systemd-resolved 2>/dev/null || true
systemctl stop systemd-resolved 2>/dev/null || true
"""
            proc = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "bash", "-c", ipv6_disable_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await proc.communicate()
            
            # Restart network to apply changes
            logging.info(f"Restarting network for {container_name}")
            proc = await asyncio.create_subprocess_exec(
                "lxc", "exec", container_name, "--", "bash", "-c",
                "systemctl restart networking 2>/dev/null || service networking restart 2>/dev/null || true",
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
            
            await asyncio.sleep(5)
            
            if not await wait_for_network(container_name):
                raise Exception(f"Network timeout after configuration for {container_name}")
        else:
            logging.info(f"IPv6 already disabled for {container_name}, skipping configuration")

        # Wait for IP address with extended timeout
        container_ip = await wait_for_ip_address(container_name, timeout=90)
        
        if not container_ip:
            logging.error(f"Failed to obtain IP for {container_name}")
            raise Exception("Could not obtain container IP address")

        # Install and configure OpenSSH
        logging.info(f"Installing OpenSSH in {container_name}...")
        
        # Install openssh-server
        install_ssh_cmd = """
apt-get update && apt-get install -y openssh-server
systemctl enable ssh
systemctl start ssh
"""
        proc = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "bash", "-c", install_ssh_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        _, stderr = await asyncio.wait_for(proc.communicate(), timeout=120)
        if proc.returncode != 0:
            raise subprocess.CalledProcessError(proc.returncode, "install ssh", stderr=stderr)

        # Configure SSH to allow password authentication
        ssh_config_cmd = """
sed -i '/^PasswordAuthentication/d' /etc/ssh/sshd_config
sed -i '/^PermitRootLogin/d' /etc/ssh/sshd_config
echo "PasswordAuthentication yes" >> /etc/ssh/sshd_config
echo "PermitRootLogin yes" >> /etc/ssh/sshd_config
systemctl restart ssh
"""
        proc = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "bash", "-c", ssh_config_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        await proc.communicate()

        # Set root password
        set_password_cmd = f"echo 'root:{ssh_password}' | chpasswd"
        proc = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "bash", "-c", set_password_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        await proc.communicate()
        if proc.returncode != 0:
            raise subprocess.CalledProcessError(proc.returncode, "set password")

        # Add port forwarding for SSH
        device_name = f"ssh-proxy-{ssh_port}"
        listen_arg = f"listen=tcp:0.0.0.0:{ssh_port}"
        connect_arg = f"connect=tcp:{container_ip}:22"

        proc = await asyncio.create_subprocess_exec(
            "lxc", "config", "device", "add", container_name, device_name, "proxy",
            listen_arg, connect_arg,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        await proc.communicate()
        if proc.returncode != 0:
            raise subprocess.CalledProcessError(proc.returncode, "add ssh proxy")

        ssh_connection = f"ssh root@jupyterhive.duckdns.org -p {ssh_port}"
        
        logging.info(f"Container {container_name} created successfully")
        logging.info(f"Container IP: {container_ip}")
        logging.info(f"SSH: {ssh_connection}")
        logging.info(f"Password: {ssh_password}")

        # Add VPS to database
        db.add_vps(user_id, username, container_name, cpu, ram, disk, 0, ssh_connection, ssh_port, ssh_password)
        
        return container_name, ssh_connection, ssh_port, ssh_password

    except Exception as e:
        logging.error(f"Error creating container {container_name}: {str(e)}")
        await cleanup_container(container_name)
        return None, None, None, None

async def cleanup_container(container_name):
    """Deletes a container in case of error"""
    try:
        logging.info(f"Cleaning up container {container_name}")
        proc = await asyncio.create_subprocess_exec(
            "lxc", "delete", container_name, "--force",
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        await asyncio.wait_for(proc.communicate(), timeout=30)
        logging.info(f"Container {container_name} deleted")
    except Exception as e:
        logging.error(f"Failed to cleanup {container_name}: {e}")

async def delete_container(container_name):
    """Gracefully deletes a container"""
    try:
        proc = await asyncio.create_subprocess_exec(
            "lxc", "list", container_name, "--format", "csv", "-c", "n",
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        stdout, _ = await proc.communicate()
        if container_name not in stdout.decode():
            logging.info(f"Container {container_name} does not exist.")
            return True

        # Force stop the container before deleting
        stop_status = await stop_container(container_name, force=True)
        if stop_status is False:
            logging.warning(f"Failed to stop container {container_name} before deletion, but proceeding with delete anyway.")

        await asyncio.sleep(2)
        
        proc = await asyncio.create_subprocess_exec(
            "lxc", "delete", container_name, "--force",
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        _, stderr = await proc.communicate()
        if proc.returncode != 0:
            raise subprocess.CalledProcessError(proc.returncode, "lxc delete", stderr=stderr)
        logging.info(f"Container {container_name} deleted successfully")
        return True
    except Exception as e:
        logging.error(f"Error deleting {container_name}: {e}")
        return False

async def regenerate_ssh_link(container_name):
    """Regenerates the SSH connection string for a given container."""
    vps_info = db.get_vps_by_container_name(container_name)
    if vps_info and vps_info['ssh_port']:
        ssh_port = vps_info['ssh_port']
        ssh_connection = f"ssh root@jupyterhive.duckdns.org -p {ssh_port}"
        return ssh_connection
    return None

async def reinstall_container(old_container_name, progress_callback=None):
    """Reinstalls an LXC container"""
    try:
        if progress_callback:
            await progress_callback("Fetching VPS information...")
            await asyncio.sleep(5)
        
        vps_info = db.get_vps_by_container_name(old_container_name)
        if not vps_info:
            logging.error(f"VPS info not found for {old_container_name}")
            if progress_callback:
                await progress_callback("Failed: VPS information not found.")
            return None, None, None, None

        user_id = vps_info['user_id']
        username = vps_info['username'] or f"user-{user_id}"
        cpu = vps_info['cpu']
        ram = vps_info['ram']
        disk = vps_info['disk']

        if progress_callback:
            await progress_callback(f"Deleting old container {old_container_name}...")
            await asyncio.sleep(5)

        if not await delete_container(old_container_name):
            if progress_callback:
                await progress_callback("Failed: Could not delete old container.")
            return None, None, None, None
        
        if progress_callback:
            await progress_callback("Removing old VPS entry from database...")
            await asyncio.sleep(5)
        
        db.delete_vps_by_container_name(old_container_name)

        if progress_callback:
            await progress_callback("Creating new container...")
            await asyncio.sleep(5)
        
        new_container_name, ssh_connection, ssh_port, ssh_password = await create_lxc_container(user_id, username, cpu, ram, disk)

        if new_container_name:
            logging.info(f"Container reinstalled as {new_container_name}")
            if progress_callback:
                await progress_callback(f"Reinstallation complete: {new_container_name}")
            return new_container_name, ssh_connection, ssh_port, ssh_password
        else:
            if progress_callback:
                await progress_callback("Failed: Could not create new container.")
            return None, None, None, None

    except Exception as e:
        logging.error(f"Error during reinstall: {str(e)}")
        if progress_callback:
            await progress_callback(f"Reinstallation failed: {str(e)}")
        return None, None, None, None

async def list_user_containers(user_id):
    """Lists all containers for a user"""
    try:
        proc = await asyncio.create_subprocess_exec(
            "lxc", "list", "--format", "csv", "-c", "n",
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        stdout, _ = await proc.communicate()
        all_containers = stdout.decode().strip().split('\n')
        return [c for c in all_containers if f"-{user_id}-" in c]
    except Exception as e:
        logging.error(f"Error listing containers: {e}")
        return []

async def get_container_info(container_name):
    """Retrieves container information with full state data, handling stopped containers."""
    try:
        proc = await asyncio.create_subprocess_exec(
            "lxc", "info", container_name,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            err_str = stderr.decode().strip()
            if "not found" in err_str.lower():
                logging.error(f"Container {container_name} not found: {err_str}")
                return None
            
            logging.warning(f"lxc info for {container_name} failed, assuming it's stopped. Stderr: {err_str}")
            return {'Status': 'Stopped', 'state': None}

        # Parse the YAML output
        output = stdout.decode()
        logging.info(f"DEBUG - Raw LXC info output:\n{output[:500]}")  # Log first 500 chars
        
        info = yaml.safe_load(output)
        
        if not info:
            logging.error(f"Failed to parse YAML for {container_name}")
            return None

        # LXC uses 'Status' with capital S, normalize it to lowercase 'status'
        if 'Status' in info:
            info['status'] = info['Status'].lower()
            logging.info(f"DEBUG - Normalized status for {container_name}: {info['status']}")
        elif 'status' in info:
            info['status'] = info['status'].lower()
        else:
            logging.warning(f"No status found in LXC info for {container_name}")
            info['status'] = 'unknown'

        # Initialize state if missing
        if info.get('state') is None:
            info['state'] = {
                'memory': {'usage': 0},
                'disk': {'root': {'usage': 0}},
                'uptime': 0,
                'network': {}
            }
        
        return info
        
    except Exception as e:
        logging.error(f"Error getting info for {container_name}: {e}")
        import traceback
        logging.error(traceback.format_exc())
        return None

async def get_container_config(container_name):
    """Retrieves container configuration in YAML format"""
    try:
        proc = await asyncio.create_subprocess_exec(
            "lxc", "config", "show", container_name,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            logging.error(f"lxc config show command failed for {container_name} with stderr: {stderr.decode().strip()}")
            return None
        return yaml.safe_load(stdout.decode())
    except Exception as e:
        logging.error(f"Error getting config for {container_name}: {e}")
        return None

async def is_container_running(container_name):
    """Checks if a container is running."""
    try:
        proc = await asyncio.create_subprocess_exec(
            "lxc", "list", container_name, "--format", "csv", "-c", "s",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            logging.warning(f"Could not get status for {container_name}: {stderr.decode().strip()}")
            return False
        return "RUNNING" in stdout.decode().strip().upper()
    except Exception as e:
        logging.error(f"Exception checking status for {container_name}: {e}")
        return False

async def pause_container(container_name):
    """Pauses an LXC container"""
    try:
        proc = await asyncio.create_subprocess_exec("lxc", "pause", container_name, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        await proc.communicate()
        if proc.returncode == 0:
            logging.info(f"Container {container_name} paused.")
            return True
        else:
            logging.error(f"Failed to pause container {container_name}.")
            return False
    except Exception as e:
        logging.error(f"Failed to pause container: {e}")
        return False

async def stop_container(container_name, force=False):
    """Stops an LXC container"""
    try:
        proc = await asyncio.create_subprocess_exec("lxc", "list", container_name, "--format", "csv", "-c", "s", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        status_result, _ = await proc.communicate()
        if "STOPPED" in status_result.decode().strip().upper():
            logging.info(f"Container {container_name} already stopped.")
            return None

        cmd = ["lxc", "stop", container_name]
        if force:
            cmd.append("--force")

        proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        _, stderr = await proc.communicate()
        if proc.returncode != 0:
            logging.error(f"lxc stop command failed for {container_name} with stderr: {stderr.decode()}")
            return False
        logging.info(f"Container {container_name} stopped.")
        return True
    except Exception as e:
        logging.error(f"Failed to stop container: {e}")
        return False

async def start_container(container_name):
    """Starts an LXC container"""
    try:
        proc = await asyncio.create_subprocess_exec("lxc", "list", container_name, "--format", "csv", "-c", "s", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        status_result, _ = await proc.communicate()
        if "RUNNING" in status_result.decode().strip().upper():
            logging.info(f"Container {container_name} already running.")
            return None

        proc = await asyncio.create_subprocess_exec("lxc", "start", container_name, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        await proc.communicate()
        
        if not await wait_for_network(container_name):
            logging.error(f"Network timeout after starting {container_name}")
            return False

        return True
    except Exception as e:
        logging.error(f"Failed to start container: {e}")
        return False

def list_port_forwards(container_name):
    """Lists existing port forwarding rules"""
    try:
        forwards_db = db.get_port_forwards_for_container(container_name)
        return [f"{f['external_port']}/{f['protocol']} -> {f['internal_port']}" for f in forwards_db]
    except Exception as e:
        logging.error(f"Error listing port forwards: {e}")
        return []

async def add_port_forward(container_name, port):
    """Adds a port forwarding rule"""
    try:
        if db.get_port_forward_by_external_port(int(port), 'tcp'):
            logging.error(f"Port {port} is already in use.")
            return False

        # Get container IP using the new function
        container_ip = await wait_for_ip_address(container_name, timeout=30)
        
        if not container_ip:
            logging.error(f"Could not find IP address for {container_name}.")
            return False

        device_name = f"proxy{port}"
        proc = await asyncio.create_subprocess_exec(
            "lxc", "config", "device", "add", container_name, device_name, "proxy",
            f"listen=tcp:0.0.0.0:{port}", f"connect=tcp:{container_ip}:{port}",
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        _, stderr = await proc.communicate()
        if proc.returncode != 0:
            logging.error(f"Failed to add proxy device for port {port} on {container_name}: {stderr.decode()}")
            return False
        
        db.add_port_forward_entry(container_name, int(port), int(port), 'tcp', device_name)
        logging.info(f"Successfully forwarded port {port} to {container_ip}:{port} for {container_name}.")
        return True
    except Exception as e:
        logging.error(f"An unexpected error occurred while adding port forward for {container_name}: {e}")
        return False

async def delete_port_forward(container_name, port):
    """Deletes a port forwarding rule"""
    try:
        forward_entry = db.get_port_forward_by_external_port(port, 'tcp')
        if not forward_entry or forward_entry['container_name'] != container_name:
            return False
        
        device_name = forward_entry['device_name']
        proc = await asyncio.create_subprocess_exec(
            "lxc", "config", "device", "remove", container_name, device_name,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        await proc.communicate()
        
        db.remove_port_forward_entry(device_name)
        return True
    except Exception as e:
        logging.error(f"Error deleting port forward: {e}")
        return False