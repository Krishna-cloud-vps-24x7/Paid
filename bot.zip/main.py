import discord
from discord.ext import commands, tasks
import os
from dotenv import load_dotenv
from datetime import datetime, timedelta
from utils.database import db
from utils.surveillance import Surveillance
from utils import lxc
import logging
import yaml
import os

load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


intents = discord.Intents.default()
intents.message_content = True
intents.members = True # Needed to fetch user objects

bot = commands.Bot(command_prefix='!', intents=intents)
bot.remove_command('help')

@tasks.loop(hours=24)
async def check_vps_payments():
    await bot.wait_until_ready()
    logging.info("Running daily VPS payment check...")
    all_vps = db.get_all_vps()
    now = datetime.now()

    for vps in all_vps:
        due_date = datetime.fromisoformat(vps['due_date'])
        user_id = vps['user_id']
        vps_id = vps['id']
        cost = vps['cost_credits']
        container_name = vps['container_name']
        status = vps['status']

        if now > due_date:
            user_balance = db.get_balance(user_id)
            user = None
            try:
                user = await bot.fetch_user(user_id)
            except discord.NotFound:
                logging.warning(f"User {user_id} not found, cannot send DM.")

            if status == 'active':
                if user_balance >= cost:
                    db.add_credits(user_id, -cost)
                    db.update_vps_due_date(vps_id)
                    logging.info(f"VPS {container_name} for user {user_id} has been renewed.")
                    if user:
                        try:
                            embed = discord.Embed(title="Automatic VPS Renewal", description=f"Your VPS `{container_name}` has been automatically renewed for one more month. {cost} credits have been deducted from your balance.", color=discord.Color.green())
                            await user.send(embed=embed)
                        except discord.Forbidden:
                            logging.warning(f"Cannot send renewal DM to user {user_id}. DMs are disabled.")
                else:
                    lxc.stop_container(container_name)
                    db.update_vps_status(vps_id, 'overdue')
                    logging.info(f"VPS {container_name} for user {user_id} is overdue and has been stopped.")
                    if user:
                        delete_timestamp = int((now + timedelta(days=2)).timestamp())
                        embed = discord.Embed(
                            title="VPS Payment Overdue",
                            description=f"Your VPS `{container_name}` has been stopped due to non-payment. You do not have enough credits ({user_balance}) to renew it for {cost} credits.",
                            color=discord.Color.orange()
                        )
                        embed.add_field(
                            name="Action Required",
                            value="Please top up your credits to reactivate your VPS. It will be automatically renewed once you have sufficient funds."
                        )
                        embed.add_field(
                            name="Deletion Date",
                            value=f"Your VPS will be permanently deleted <t:{delete_timestamp}:R> if not renewed.",
                            inline=False
                        )
                        try:
                            await user.send(embed=embed)
                        except discord.Forbidden:
                            logging.warning(f"Cannot send overdue DM to user {user_id}. DMs are disabled.")
            elif status == 'overdue':
                if user_balance >= cost:
                    db.add_credits(user_id, -cost)
                    db.update_vps_due_date(vps_id)
                    lxc.start_container(container_name)
                    logging.info(f"Overdue VPS {container_name} for user {user_id} has been renewed and started.")
                    if user:
                        try:
                            await user.send(f"✅ Your overdue VPS `{container_name}` has been renewed and is starting up.")
                        except discord.Forbidden:
                            logging.warning(f"Cannot send renewal DM to user {user_id}. DMs are disabled.")
                elif now > (due_date + timedelta(days=2)):
                    logging.info(f"VPS {container_name} for user {user_id} is being deleted due to non-payment.")
                    if lxc.delete_container(container_name):
                        db.delete_vps(vps_id)
                        logging.info(f"VPS {container_name} for user {user_id} has been deleted.")
                        if user:
                            try:
                                embed = discord.Embed(
                                    title="VPS Deleted",
                                    description=f"Your VPS `{container_name}` has been permanently deleted due to non-payment.",
                                    color=discord.Color.red()
                                )
                                await user.send(embed=embed)
                            except discord.Forbidden:
                                logging.warning(f"Cannot send deletion DM to user {user_id}. DMs are disabled.")
                    else:
                        logging.error(f"Failed to delete container {container_name} for user {user_id}.")

@bot.check
async def is_in_correct_guild(ctx):
    if ctx.guild is None:
        return False
    return ctx.guild.id == 1337813607530102814

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return  # Ignore command not found errors
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"You are missing a required argument: `{error.param.name}`. Please use `!help {ctx.command.name}` for more information.")
    elif isinstance(error, commands.CommandError):
        await ctx.send(f"An error occurred while executing the command: {error}")
    else:
        print(f"An error occurred: {error}")

@bot.event
async def on_ready():
    print(f'We have logged in as {bot.user}')
    for filename in os.listdir('./commands'):
        if filename.endswith('.py') and filename != 'tos.py':
            try:
                await bot.load_extension(f'commands.{filename[:-3]}')
                print(f'Loaded command: {filename[:-3]}')
            except Exception as e:
                print(f'Failed to load command: {filename[:-3]}')
                print(f'[ERROR] {e}')
    try:
        guild_id = 1337813607530102814  # Replace with your guild ID
        guild = discord.Object(id=guild_id)
        # bot.tree.clear_commands(guild=guild) # Uncomment to clear commands
        await bot.tree.sync(guild=guild)
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} command(s)")
    except Exception as e:
        print(e)

    check_vps_payments.start()

    try:
        surveillance = Surveillance(bot)
        surveillance.check_containers_for_mining.start()
        logging.info("Surveillance task started.")
    except ValueError as e:
        logging.error(f"Failed to start surveillance: {e}")

    await send_tos_embed(bot)

async def send_tos_embed(bot):
    import yaml
    import os

    tos_path = os.path.join(os.path.dirname(__file__), 'condition-utilisation', 'tos.yaml')

    try:
        with open(tos_path, 'r', encoding='utf-8') as f:
            tos_data = yaml.safe_load(f)
        logging.info(f"Successfully loaded tos.yaml. Keys: {tos_data.keys()}")
    except FileNotFoundError:
        logging.error("TOS file not found during automatic sending.")
        return
    except yaml.YAMLError as e:
        logging.error(f"Error reading TOS file for automatic sending: {e}")
        return

    tos_content = tos_data.get('tos', {})
    
    embed = discord.Embed(
        title=tos_content.get('title', 'Terms of Service'),
        color=discord.Color.orange()
    )

    for section in tos_content.get('sections', []):
        embed.add_field(name=section.get('title'), value=section.get('content'), inline=False)

    legal_notice = tos_data.get('legal_notice', {})
    logging.info(f"Legal notice data: {legal_notice}")
    if legal_notice:
        legal_text = f"Address: {legal_notice.get('address', 'N/A')}\n"
        legal_text += f"Postal Code: {legal_notice.get('postal_code', 'N/A')}\n"
        legal_text += f"City: {legal_notice.get('city', 'N/A')}\n"
        legal_text += f"Country: {legal_notice.get('country', 'N/A')}\n"
        legal_text += f"Contact Email: {legal_notice.get('contact_email', 'N/A')}"
        embed.add_field(name="Legal Notice", value=legal_text, inline=False)
        logging.info("Legal Notice field added to embed.")

    user_id = 1047760053509312642
    user = await bot.fetch_user(user_id)
    
    if user:
        embed.set_footer(text=f"Provided by {user.name}", icon_url=user.avatar.url if user.avatar else None)

    target_channel_id = 1430625796073980070
    target_channel = bot.get_channel(target_channel_id)

    if target_channel:
        # Try to get existing message ID from DB
        stored_message_id, stored_channel_id = db.get_tos_message_id()

        if stored_message_id and stored_channel_id == target_channel_id:
            try:
                message = await target_channel.fetch_message(stored_message_id)
                await message.edit(embed=embed)
                logging.info(f"TOS embed updated in channel {target_channel.id} (message ID: {stored_message_id})")
            except discord.NotFound:
                logging.warning(f"Stored TOS message {stored_message_id} not found. Sending new message.")
                new_message = await target_channel.send(embed=embed)
                db.save_tos_message_id(new_message.id, target_channel_id)
                logging.info(f"New TOS embed sent and ID saved in channel {target_channel.id} (message ID: {new_message.id})")
            except discord.Forbidden:
                logging.error(f"Cannot edit message in channel {target_channel.id}. Permissions issue.")
        else:
            # No stored message or channel ID mismatch, send new message
            new_message = await target_channel.send(embed=embed)
            db.save_tos_message_id(new_message.id, target_channel_id)
            logging.info(f"New TOS embed sent and ID saved in channel {target_channel.id} (message ID: {new_message.id})")
    else:
        logging.error(f"Channel for sending TOS ({target_channel_id}) not found during automatic sending.")

    
bot.run(os.getenv("DISCORD_TOKEN"))