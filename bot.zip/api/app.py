import sys
import os
import logging
from functools import wraps
from flask import Flask, request, jsonify
from dotenv import load_dotenv
import asyncio
from threading import Thread

# Configuration du projet
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, project_root)

# Charger les variables d'environnement
load_dotenv()

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Import des utilitaires LXC
from utils import lxc

app = Flask(__name__)

# Récupérer la clé d'API depuis les variables d'environnement
API_KEY = os.getenv("API_KEY")

if not API_KEY:
    logger.error("API_KEY not found in environment variables!")
    raise ValueError("API_KEY must be set in .env file")


# ============================================================================
# MIDDLEWARE D'AUTHENTIFICATION
# ============================================================================

def require_api_key(f):
    """Décorateur pour vérifier la clé API"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        provided_key = request.headers.get('X-API-KEY')
        
        if not provided_key:
            logger.warning(f"API call without key from {request.remote_addr}")
            return jsonify({"error": "API key required"}), 401
        
        if provided_key != API_KEY:
            logger.warning(f"Invalid API key attempt from {request.remote_addr}")
            return jsonify({"error": "Invalid API key"}), 403
        
        return f(*args, **kwargs)
    
    return decorated_function


# ============================================================================
# HELPER FUNCTION POUR ASYNCIO
# ============================================================================

def run_async(coro):
    """Exécute une coroutine de manière synchrone pour Flask"""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


# ============================================================================
# ROUTES - HEALTH CHECK
# ============================================================================

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint (no auth required)"""
    return jsonify({"status": "healthy"}), 200


# ============================================================================
# ROUTES - USER CONTAINERS
# ============================================================================

@app.route('/lxc/user/<user_id>', methods=['GET'])
@require_api_key
def get_user_containers(user_id):
    """Liste tous les conteneurs d'un utilisateur"""
    try:
        containers = run_async(lxc.list_user_containers(user_id))
        return jsonify(containers), 200
    except Exception as e:
        logger.error(f"Error listing containers for user {user_id}: {e}")
        return jsonify({"error": str(e)}), 500


# ============================================================================
# ROUTES - CONTAINER INFO
# ============================================================================

@app.route('/lxc/container/<container_name>/info', methods=['GET'])
@require_api_key
def get_container_info(container_name):
    """Obtient les informations d'un conteneur"""
    try:
        info = run_async(lxc.get_container_info(container_name))
        if info is None:
            return jsonify({"error": "Container not found"}), 404
        return jsonify(info), 200
    except Exception as e:
        logger.error(f"Error getting info for {container_name}: {e}")
        return jsonify({"error": str(e)}), 500


@app.route('/lxc/container/<container_name>/config', methods=['GET'])
@require_api_key
def get_container_config(container_name):
    """Obtient la configuration d'un conteneur"""
    try:
        config = run_async(lxc.get_container_config(container_name))
        if config is None:
            return jsonify({"error": "Container not found or error getting config"}), 404
        return jsonify(config), 200
    except Exception as e:
        logger.error(f"Error getting config for {container_name}: {e}")
        return jsonify({"error": str(e)}), 500


@app.route('/lxc/container/<container_name>/status', methods=['GET'])
@require_api_key
def get_container_status(container_name):
    """Vérifie si un conteneur est en cours d'exécution"""
    try:
        is_running = run_async(lxc.is_container_running(container_name))
        return jsonify({"running": is_running}), 200
    except Exception as e:
        logger.error(f"Error checking status for {container_name}: {e}")
        return jsonify({"error": str(e)}), 500


@app.route('/lxc/container/<container_name>/processes', methods=['GET'])
@require_api_key
def get_container_processes(container_name):
    """Récupère les processus d'un conteneur pour la surveillance"""
    try:
        command = """
        echo '=== TOP PROCESSES ==='
        ps -eo %cpu,%mem,pid,user,args --sort=-%cpu | head -n 11
        echo ''
        echo '=== NETWORK CONNECTIONS ==='
        ss -tunp 2>/dev/null | grep -v '127.0.0.1' | head -n 10 || echo 'No external connections'
        """
        
        proc = run_async(asyncio.create_subprocess_exec(
            "lxc", "exec", container_name, "--", "bash", "-c", command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        ))
        
        async def get_output():
            stdout, stderr = await proc.communicate()
            if proc.returncode != 0:
                return None
            return stdout.decode()
        
        output = run_async(get_output())
        
        if output:
            return jsonify({"processes": output}), 200
        else:
            return jsonify({"error": "Failed to get processes"}), 500
            
    except Exception as e:
        logger.error(f"Error getting processes for {container_name}: {e}")
        return jsonify({"error": str(e)}), 500


# ============================================================================
# ROUTES - CONTAINER MANAGEMENT
# ============================================================================

@app.route('/lxc/container', methods=['POST'])
@require_api_key
def create_container():
    """Crée un nouveau conteneur LXC"""
    try:
        data = request.get_json()
        
        # Validation des paramètres
        required_fields = ['user_id', 'username', 'cpu', 'ram', 'disk']
        if not all(field in data for field in required_fields):
            return jsonify({"error": "Missing required fields"}), 400
        
        user_id = data['user_id']
        username = data['username']
        cpu = int(data['cpu'])
        ram = float(data['ram'])
        disk = float(data['disk'])
        
        # Création du conteneur
        result = run_async(lxc.create_lxc_container(user_id, username, cpu, ram, disk))
        
        if result[0] is None:
            return jsonify({"error": "Container creation failed"}), 500
        
        container_name, ssh_link, ssh_port, ssh_password = result
        
        return jsonify({
            "status": "success",
            "container_name": container_name,
            "ssh_link": ssh_link,
            "ssh_port": ssh_port,
            "ssh_password": ssh_password
        }), 201
        
    except Exception as e:
        logger.error(f"Error creating container: {e}")
        return jsonify({"error": str(e)}), 500


@app.route('/lxc/container/<container_name>', methods=['DELETE'])
@require_api_key
def delete_container(container_name):
    """Supprime un conteneur"""
    try:
        result = run_async(lxc.delete_container(container_name))
        
        if result:
            return jsonify({"deleted": True, "container_name": container_name}), 200
        else:
            return jsonify({"deleted": False, "error": "Failed to delete container"}), 500
            
    except Exception as e:
        logger.error(f"Error deleting container {container_name}: {e}")
        return jsonify({"error": str(e)}), 500


@app.route('/lxc/container/<container_name>/reinstall', methods=['POST'])
@require_api_key
def reinstall_container(container_name):
    """Réinstalle un conteneur"""
    try:
        result = run_async(lxc.reinstall_container(container_name))
        
        if result[0] is None:
            return jsonify({"status": "error", "message": "Reinstall failed"}), 500
        
        new_container_name, ssh_link, ssh_port, ssh_password = result
        
        return jsonify({
            "status": "success",
            "result": [new_container_name, ssh_link, ssh_port, ssh_password]
        }), 200
        
    except Exception as e:
        logger.error(f"Error reinstalling container {container_name}: {e}")
        return jsonify({"error": str(e)}), 500


# ============================================================================
# ROUTES - CONTAINER ACTIONS
# ============================================================================

@app.route('/lxc/container/<container_name>/start', methods=['POST'])
@require_api_key
def start_container(container_name):
    """Démarre un conteneur"""
    try:
        result = run_async(lxc.start_container(container_name))
        
        return jsonify({
            "status": "success",
            "result": result
        }), 200
        
    except Exception as e:
        logger.error(f"Error starting container {container_name}: {e}")
        return jsonify({"error": str(e)}), 500


@app.route('/lxc/container/<container_name>/stop', methods=['POST'])
@require_api_key
def stop_container(container_name):
    """Arrête un conteneur"""
    try:
        data = request.get_json() or {}
        force = data.get('force', False)
        
        result = run_async(lxc.stop_container(container_name, force=force))
        
        return jsonify({
            "status": "success",
            "result": result
        }), 200
        
    except Exception as e:
        logger.error(f"Error stopping container {container_name}: {e}")
        return jsonify({"error": str(e)}), 500


@app.route('/lxc/container/<container_name>/restart', methods=['POST'])
@require_api_key
def restart_container(container_name):
    """Redémarre un conteneur"""
    try:
        # Stop puis start
        stop_result = run_async(lxc.stop_container(container_name, force=True))
        if stop_result is False:
            return jsonify({"status": "error", "message": "Failed to stop container"}), 500
        
        start_result = run_async(lxc.start_container(container_name))
        if start_result is False:
            return jsonify({"status": "error", "message": "Failed to start container"}), 500
        
        return jsonify({"status": "success"}), 200
        
    except Exception as e:
        logger.error(f"Error restarting container {container_name}: {e}")
        return jsonify({"error": str(e)}), 500


@app.route('/lxc/container/<container_name>/pause', methods=['POST'])
@require_api_key
def pause_container(container_name):
    """Met en pause un conteneur"""
    try:
        result = run_async(lxc.pause_container(container_name))
        
        return jsonify({
            "status": "success",
            "result": result
        }), 200
        
    except Exception as e:
        logger.error(f"Error pausing container {container_name}: {e}")
        return jsonify({"error": str(e)}), 500


@app.route('/lxc/container/<container_name>/resume', methods=['POST'])
@require_api_key
def resume_container(container_name):
    """Reprend un conteneur en pause"""
    try:
        result = run_async(lxc.start_container(container_name))
        
        return jsonify({
            "status": "success",
            "result": result
        }), 200
        
    except Exception as e:
        logger.error(f"Error resuming container {container_name}: {e}")
        return jsonify({"error": str(e)}), 500


# ============================================================================
# ROUTES - SSH
# ============================================================================

@app.route('/lxc/container/<container_name>/regenerate-ssh', methods=['POST'])
@require_api_key
def regenerate_ssh(container_name):
    """Régénère le lien SSH pour un conteneur"""
    try:
        ssh_link = run_async(lxc.regenerate_ssh_link(container_name))
        
        if ssh_link:
            return jsonify({
                "status": "success",
                "ssh_link": ssh_link
            }), 200
        else:
            return jsonify({"status": "error", "message": "Failed to regenerate SSH link"}), 500
            
    except Exception as e:
        logger.error(f"Error regenerating SSH for {container_name}: {e}")
        return jsonify({"error": str(e)}), 500


# ============================================================================
# ROUTES - PORT FORWARDING
# ============================================================================

@app.route('/lxc/container/<container_name>/ports', methods=['GET'])
@require_api_key
def get_port_forwards(container_name):
    """Liste les redirections de ports d'un conteneur"""
    try:
        forwards = lxc.list_port_forwards(container_name)
        return jsonify({"ports": forwards}), 200
    except Exception as e:
        logger.error(f"Error listing ports for {container_name}: {e}")
        return jsonify({"error": str(e)}), 500


@app.route('/lxc/container/<container_name>/ports', methods=['POST'])
@require_api_key
def add_port_forward(container_name):
    """Ajoute une redirection de port"""
    try:
        data = request.get_json()
        port = data.get('port')
        
        if not port:
            return jsonify({"error": "Port is required"}), 400
        
        result = run_async(lxc.add_port_forward(container_name, port))
        
        return jsonify({
            "status": "success" if result else "error",
            "result": result
        }), 200 if result else 500
        
    except Exception as e:
        logger.error(f"Error adding port forward for {container_name}: {e}")
        return jsonify({"error": str(e)}), 500


@app.route('/lxc/container/<container_name>/ports', methods=['DELETE'])
@require_api_key
def delete_port_forward(container_name):
    """Supprime une redirection de port"""
    try:
        data = request.get_json()
        port = data.get('port')
        
        if not port:
            return jsonify({"error": "Port is required"}), 400
        
        result = run_async(lxc.delete_port_forward(container_name, port))
        
        return jsonify({
            "status": "success" if result else "error",
            "result": result
        }), 200 if result else 500
        
    except Exception as e:
        logger.error(f"Error deleting port forward for {container_name}: {e}")
        return jsonify({"error": str(e)}), 500


# ============================================================================
# ERROR HANDLERS
# ============================================================================

@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Endpoint not found"}), 404


@app.errorhandler(500)
def internal_error(error):
    logger.error(f"Internal server error: {error}")
    return jsonify({"error": "Internal server error"}), 500


# ============================================================================
# MAIN
# ============================================================================

if __name__ == '__main__':
    logger.info("Starting LXC API Flask Server...")
    logger.info(f"API Key configured: {'Yes' if API_KEY else 'No'}")
    
    # Mode production avec gunicorn recommandé
    # En développement:
    app.run(host='0.0.0.0', port=5000, debug=False)