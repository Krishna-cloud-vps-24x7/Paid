import discord
from discord.ext import commands, tasks
from discord import app_commands
import aiohttp
import os
import time
from utils.database import db
from utils.billing import try_renew_vps

class BuyCredits(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.oxapay_merchant_key = os.getenv("OXAPAY_MERCHANT_KEY")
        self.check_payments.start()

    def cog_unload(self):
        self.check_payments.cancel()

    @commands.hybrid_command(name="buy_credits", description="Buy credits with cryptocurrency")
    @app_commands.guild_only()
    @app_commands.describe(credits="The amount of credits to buy", user="The user to buy credits for (optional)")
    async def buy_credits(self, ctx: commands.Context, credits: int, user: discord.User = None):
        if not self.oxapay_merchant_key:
            await ctx.send("The payment configuration is not complete. Please contact an administrator.", ephemeral=True)
            return

        if credits < 9:
            await ctx.send("The minimum amount of credits to buy is 9.", ephemeral=True)
            return

        target_user = user if user else ctx.author
        price = round((credits / 100) * 1.14, 2)

        await ctx.send("Please check your private messages for the payment link.", ephemeral=True)

        async with aiohttp.ClientSession() as session:
            payload = {
                "merchant": self.oxapay_merchant_key,
                "amount": price,
                "currency": "USD",
                "lifeTime": 90, # The payment will be valid for 90 minutes
            }
            try:
                async with session.post("https://api.oxapay.com/merchants/request", json=payload) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        pay_link = data.get('payLink')
                        track_id = data.get('trackId')
                        if pay_link and track_id:
                            expiration_time = int(time.time()) + 90 * 60
                            db.add_transaction(track_id, target_user.id, credits, expiration_time)

                            embed = discord.Embed(title="Payment for Credits", description=f"Please use the link below to pay ${price:.2f} for {credits} credits.", color=discord.Color.blue())
                            embed.add_field(name="Payment Link", value=pay_link)
                            embed.add_field(name="Transaction ID", value=track_id, inline=False)
                            embed.set_footer(text="The bot will automatically check the payment status.")
                            try:
                                await target_user.send(embed=embed)
                            except discord.Forbidden:
                                await ctx.followup.send("I could not send you a private message. Please enable your DMs.", ephemeral=True)
                        else:
                            await ctx.followup.send("An error occurred while creating the payment. Please try again.", ephemeral=True)
                    else:
                        await ctx.followup.send(f"OxaPay API Error: {resp.status}", ephemeral=True)
            except Exception as e:
                await ctx.followup.send(f"An error occurred: {e}", ephemeral=True)

    @tasks.loop(seconds=5)
    async def check_payments(self):
        unattributed_transactions = db.get_unattributed_transactions()
        for transaction in unattributed_transactions:
            track_id, user_id, credits, expiration_time, _ = transaction

            if time.time() > expiration_time:
                # Mark as attributed to prevent further checks
                db.mark_transaction_as_attributed(track_id)
                continue

            headers = {
                'merchant_api_key': self.oxapay_merchant_key,
                'Content-Type': 'application/json'
            }
            url = f'https://api.oxapay.com/v1/payment/{track_id}'

            async with aiohttp.ClientSession() as session:
                try:
                    async with session.get(url, headers=headers) as resp:
                        if resp.status == 200:
                            response_data = await resp.json()
                            payment_data = response_data.get('data', {})
                            if payment_data.get('status') == 'paid':
                                db.add_credits(user_id, credits)
                                db.mark_transaction_as_attributed(track_id)
                                await try_renew_vps(self.bot, user_id)
                                try:
                                    user = await self.bot.fetch_user(user_id)
                                    await user.send(f"{credits} credits have been added to your account.")
                                except discord.Forbidden:
                                    pass # Can't send DMs to this user
                except Exception as e:
                    print(f"Error while checking payment {track_id}: {e}")

    @check_payments.before_loop
    async def before_check_payments(self):
        await self.bot.wait_until_ready()

async def setup(bot: commands.Bot):
    await bot.add_cog(BuyCredits(bot))
