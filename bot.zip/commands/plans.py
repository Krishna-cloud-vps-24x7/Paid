import discord
from discord.ext import commands
from discord import app_commands
from utils.database import db
import math
import asyncio
import logging
import aiohttp
import os

# Configuration API
API_BASE_URL = os.getenv("API_URL", "http://127.0.0.1:5000")
API_KEY = os.getenv("API_KEY")

# --- Pricing ---
PRICES = {
    "cpu": 0.35,    # per core
    "ram": 0.25,    # per GB
    "disk": 0.025    # per GB
}
USD_TO_CREDITS_RATE = 100 / 1.14

def usd_to_credits(usd_amount):
    return math.ceil(usd_amount * USD_TO_CREDITS_RATE)


# Helper pour les appels API
async def api_post(endpoint: str, data: dict = None):
    """Effectue un appel POST à l'API"""
    headers = {'X-API-KEY': API_KEY}
    async with aiohttp.ClientSession() as session:
        async with session.post(f"{API_BASE_URL}{endpoint}", headers=headers, json=data) as response:
            if response.status in [200, 201]:
                return await response.json()
            return None


# --- UI Components ---
class VpsConfigModal(discord.ui.Modal, title="Configure your VPS"):
    cpu = discord.ui.TextInput(label="CPU Cores", placeholder="e.g., 1, 2, 4", required=True)
    ram = discord.ui.TextInput(label="RAM (GB)", placeholder="e.g., 1, 2, 8", required=True)
    disk = discord.ui.TextInput(label="Disk (GB)", placeholder="e.g., 10, 20, 50", required=True)

    def __init__(self, bot: commands.Bot):
        super().__init__()
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)

        try:
            cpu_cores = int(self.cpu.value)
            ram_value = self.ram.value.replace(',', '.')
            disk_value = self.disk.value.replace(',', '.')
            
            ram_gb = float(ram_value)
            disk_gb = float(disk_value)
            if cpu_cores <= 0 or ram_gb <= 0 or disk_gb <= 0:
                raise ValueError()
            if cpu_cores > 5:
                embed = discord.Embed(
                    title="Configuration Error",
                    description="You cannot request more than 5 CPU cores.",
                    color=discord.Color.red()
                )
                await interaction.followup.send(embed=embed, ephemeral=True)
                return
        except ValueError:
            embed = discord.Embed(
                title="Configuration Error",
                description="Please enter valid positive numerical values.",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
            return

        cost_usd = (cpu_cores * PRICES["cpu"]) + (ram_gb * PRICES["ram"]) + (disk_gb * PRICES["disk"])
        cost_credits = usd_to_credits(cost_usd)

        user_balance = db.get_balance(interaction.user.id)

        if user_balance < cost_credits:
            embed = discord.Embed(
                title="Insufficient Balance",
                description=f"This VPS costs {cost_credits} credits, but you only have {user_balance} credits.",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
            return

        # Create the confirmation embed
        confirmation_embed = discord.Embed(
            title="Confirm Your VPS Purchase",
            description="Please confirm the details of your purchase.",
            color=discord.Color.blurple()
        )
        confirmation_embed.add_field(name="Configuration", value=f"{cpu_cores} CPU, {ram_gb}GB RAM, {disk_gb}GB Disk", inline=False)
        confirmation_embed.add_field(name="Cost", value=f"${cost_usd:.2f} ({cost_credits} credits)", inline=False)
        confirmation_embed.set_footer(text="You have 3 minutes to confirm.")

        # Send the confirmation embed with Accept/Refuse buttons
        confirm_view = ConfirmPurchaseView(self.bot, cpu_cores, ram_gb, disk_gb, cost_usd, cost_credits, interaction.user.id, interaction.user.name, interaction)
        await interaction.followup.send(embed=confirmation_embed, view=confirm_view, ephemeral=True)


class PlanView(discord.ui.View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(label="Buy VPS", style=discord.ButtonStyle.success, custom_id="buy_vps_button")
    async def buy_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = VpsConfigModal(self.bot)
        await interaction.response.send_modal(modal)


class ConfirmPurchaseView(discord.ui.View):
    def __init__(self, bot: commands.Bot, cpu_cores: int, ram_gb: float, disk_gb: float, cost_usd: float, cost_credits: int, user_id: int, username: str, original_interaction: discord.Interaction):
        super().__init__(timeout=180)
        self.bot = bot
        self.cpu_cores = cpu_cores
        self.ram_gb = ram_gb
        self.disk_gb = disk_gb
        self.cost_usd = cost_usd
        self.cost_credits = cost_credits
        self.user_id = user_id
        self.username = username
        self.original_interaction = original_interaction

    @discord.ui.button(label="Accept", style=discord.ButtonStyle.success)
    async def accept_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True, thinking=True)
        
        # Deduct credits here, as user accepted
        db.add_credits(self.user_id, -self.cost_credits)

        # Edit the original message to show accepted status
        accepted_embed = discord.Embed(
            title="Purchase Confirmed!",
            description="Your VPS is being created. This may take a few minutes. I will send you your credentials via private message shortly.",
            color=discord.Color.green()
        )
        accepted_embed.add_field(name="Configuration", value=f"{self.cpu_cores} CPU, {self.ram_gb}GB RAM, {self.disk_gb}GB Disk", inline=False)
        accepted_embed.add_field(name="Cost", value=f"${self.cost_usd:.2f} ({self.cost_credits} credits)", inline=False)
        await self.original_interaction.edit_original_response(embed=accepted_embed, view=None)

        # Send a followup message to the button interaction to clear the "thinking" state
        followup_message = await interaction.followup.send("Processing your VPS creation... 0%", ephemeral=True)

        # Start the VPS creation and progress update in a background task
        asyncio.create_task(self._create_vps_and_update_progress(followup_message))

    async def _create_vps_and_update_progress(self, followup_message: discord.WebhookMessage):
        """Handles the VPS creation and updates the progress message."""
        user = await self.bot.fetch_user(self.user_id)
        
        # Initial message
        await followup_message.edit(content="Processing your VPS creation... 0%")

        # Simulate progress before the blocking call
        for percent in range(10, 91, 10):
            await asyncio.sleep(5)
            await followup_message.edit(content=f"Processing your VPS creation... {percent}%")
        
        container_name, ssh_link = None, None
        try:
            # Call the API to create container
            result = await api_post("/lxc/container", data={
                "user_id": self.user_id,
                "username": self.username,
                "cpu": self.cpu_cores,
                "ram": self.ram_gb,
                "disk": self.disk_gb
            })
            
            # After API call, update to 100%
            await followup_message.edit(content="Processing your VPS creation... 100%")
            await asyncio.sleep(2)

            if result and result.get("status") == "success":
                container_name = result.get("container_name")
                ssh_link = result.get("ssh_link")
                ssh_port = result.get("ssh_port")
                ssh_password = result.get("ssh_password")
                
                # Add VPS to database
                db.add_vps(
                    self.user_id, 
                    self.username, 
                    container_name, 
                    self.cpu_cores, 
                    self.ram_gb, 
                    self.disk_gb, 
                    self.cost_credits,
                    ssh_link, 
                    ssh_port, 
                    ssh_password
                )
                
                try:
                    embed = discord.Embed(
                        title="Your VPS is Ready!",
                        description=f"Your VPS `{container_name}` with {self.cpu_cores} CPU, {self.ram_gb}GB RAM, and {self.disk_gb}GB Disk is now online.",
                        color=discord.Color.green()
                    )
                    embed.add_field(
                        name="SSH Connection",
                        value=f"```\n{ssh_link}\n```",
                        inline=False
                    )
                    embed.add_field(
                        name="Password",
                        value=f"```\n{ssh_password}\n```",
                        inline=False
                    )
                    embed.set_footer(text="Keep your SSH credentials safe!")
                    await user.send(embed=embed)
                    await followup_message.edit(content="VPS creation complete! Check your DMs for credentials.")
                except discord.Forbidden:
                    logging.warning(f"Could not send DM to user {user.id}. They may have DMs disabled.")
                    await followup_message.edit(content="VPS creation complete, but I could not DM you the credentials. Please check your Discord privacy settings.")
            else:
                # Refund with compensation
                db.add_credits(self.user_id, self.cost_credits + 1)
                embed = discord.Embed(
                    title="VPS Creation Failed",
                    description="I could not create your VPS. The credits for this purchase have been refunded to your account. Please contact support if this issue persists.",
                    color=discord.Color.red()
                )
                await user.send(embed=embed)
                await followup_message.edit(content="VPS creation failed. Credits refunded.")

        except Exception as e:
            logging.error(f"Error in container creation task for user {self.user_id}: {e}")
            import traceback
            traceback.print_exc()
            
            # Refund credits
            db.add_credits(self.user_id, self.cost_credits)
            embed = discord.Embed(
                title="Unexpected Error",
                description="An unexpected error occurred while creating your VPS. Your credits have been refunded.",
                color=discord.Color.red()
            )
            await user.send(embed=embed)
            await followup_message.edit(content="An unexpected error occurred during VPS creation. Credits refunded.")
        finally:
            self.stop()

    @discord.ui.button(label="Refuse", style=discord.ButtonStyle.danger)
    async def refuse_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        
        # Edit the original message to show refused status
        refused_embed = discord.Embed(
            title="Purchase Cancelled",
            description="You have cancelled the purchase of your VPS.",
            color=discord.Color.red()
        )
        refused_embed.add_field(name="Configuration", value=f"{self.cpu_cores} CPU, {self.ram_gb}GB RAM, {self.disk_gb}GB Disk", inline=False)
        refused_embed.add_field(name="Cost", value=f"${self.cost_usd:.2f} ({self.cost_credits} credits)", inline=False)
        await self.original_interaction.edit_original_response(embed=refused_embed, view=None)
        self.stop()


# --- Cog ---
class Plans(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        if not hasattr(bot, 'plan_view_added'):
            bot.add_view(PlanView(bot))
            bot.plan_view_added = True

    @commands.hybrid_command(name="plans", description="Shows the pricing for VPS plans.")
    @app_commands.guild_only()
    async def plans(self, ctx: commands.Context):
        embed = discord.Embed(
            title="VPS Hosting Plans",
            description="Configure and purchase your own custom LXC container.",
            color=discord.Color.blurple()
        )
        embed.add_field(
            name="CPU",
            value=f"${PRICES['cpu']:.2f} / {usd_to_credits(PRICES['cpu'])} credits per core",
            inline=False
        )
        embed.add_field(
            name="RAM",
            value=f"${PRICES['ram']:.2f} / {usd_to_credits(PRICES['ram'])} credits per GB",
            inline=False
        )
        embed.add_field(
            name="Disk",
            value=f"${PRICES['disk']:.2f} / {usd_to_credits(PRICES['disk'])} credits per GB",
            inline=False
        )
        embed.set_footer(text="Click the button below to configure and purchase your VPS.")

        await ctx.send(embed=embed, view=PlanView(self.bot))


async def setup(bot: commands.Bot):
    await bot.add_cog(Plans(bot))