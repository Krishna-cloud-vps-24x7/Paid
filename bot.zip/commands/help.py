import discord
from discord.ext import commands
from discord import app_commands

class Help(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.hybrid_command(name="help", description="Shows help for commands.")
    @app_commands.guild_only()
    async def help(self, ctx: commands.Context, command_name: str = None):
        if command_name is None:
            # Show all commands
            embed = discord.Embed(title="Help", description="Here is a list of all commands:", color=discord.Color.blue())
            for command in self.bot.commands:
                if command.name == 'help' or not isinstance(command, commands.HybridCommand):
                    continue
                embed.add_field(name=command.name, value=f"{command.description}\nUsage: `/{command.name}` or `!{command.name}`", inline=False)
            await ctx.send(embed=embed)
        else:
            # Show help for a specific command
            command = self.bot.get_command(command_name)
            if command is None:
                await ctx.send(f"Command `{command_name}` not found.")
                return

            embed = discord.Embed(title=f"Help for {command.name}", description=command.description, color=discord.Color.blue())
            if isinstance(command, commands.HybridCommand):
                # Usage
                usage = f"`/{command.name}`\n`!{command.name} {command.signature}`"
                embed.add_field(name="Usage", value=usage, inline=False)

                # Aliases
                if command.aliases:
                    aliases = ", ".join([f"`!{alias}`" for alias in command.aliases])
                    embed.add_field(name="Aliases", value=aliases, inline=False)

            await ctx.send(embed=embed)

async def setup(bot: commands.Bot):
    await bot.add_cog(Help(bot))
